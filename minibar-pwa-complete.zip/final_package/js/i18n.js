/**
 * Modul pro podporu více jazyků
 */

// Dostupné jazyky
export const AVAILABLE_LANGUAGES = ['cs', 'en'];

// Výchozí jazyk
export const DEFAULT_LANGUAGE = 'cs';

// Klíč pro uložení jazyka v localStorage
const LANGUAGE_KEY = 'selectedLanguage';

// Překlady textů
export const translations = {
  cs: {
    // Obecné
    appTitle: 'Správa Minibaru',
    save: 'Uložit',
    cancel: 'Zrušit',
    confirm: 'Potvrdit',
    delete: 'Smazat',
    close: 'Zavřít',
    
    // Vily
    villaSelection: 'Výběr vily',
    ohYeahVilla: 'Oh Yeah Villa',
    amazingPoolVilla: 'Amazing Pool Villa',
    littleCastleVilla: 'Little Castle Villa',
    
    // Kategorie
    categories: 'Kategorie',
    all: 'Vše',
    nonAlcoholic: 'Nealko',
    alcoholic: 'Alkoholické',
    beer: 'Pivo',
    relax: 'Relax',
    
    // Inventář
    inventory: 'Minibar Položky',
    customPrice: 'Vlastní cena',
    
    // Nastavení
    settings: 'Nastavení',
    guests: 'Počet hostů',
    nights: 'Počet nocí',
    currency: 'Měna',
    paymentMethod: 'Způsob platby',
    discount: 'Sleva 10%',
    
    // Platební metody
    cash: 'Hotově',
    card: 'Kartou',
    unpaid: 'Neplaceno',
    
    // Přehled
    overview: 'Přehled',
    totalItems: 'Počet položek',
    totalAmount: 'Celková částka',
    
    // Košík
    cart: 'Košík',
    cartEmpty: 'Košík je prázdný',
    addToCart: 'Přidat do košíku',
    removeFromCart: 'Odstranit z košíku',
    clearCart: 'Vyprázdnit košík',
    total: 'Celkem',
    
    // Množství
    quantity: 'Množství',
    selectQuantity: 'Vyberte množství',
    enterQuantity: 'Zadejte množství',
    
    // Faktura
    invoice: 'Faktura',
    generateInvoice: 'Generovat fakturu',
    printInvoice: 'Tisk faktury',
    exportToPDF: 'Export do PDF',
    date: 'Datum',
    items: 'Položky',
    subtotal: 'Mezisoučet',
    discountAmount: 'Sleva',
    cityTax: 'City Tax',
    
    // Notifikace
    itemAdded: 'přidáno do košíku',
    notificationSettings: 'Nastavení notifikací',
    notificationDuration: 'Doba zobrazení notifikace',
    notificationSound: 'Zvukové upozornění',
    
    // Historie
    history: 'Historie objednávek',
    noHistory: 'Žádné objednávky v historii',
    orderDate: 'Datum objednávky',
    viewOrder: 'Zobrazit objednávku',
    deleteOrder: 'Smazat objednávku',
    searchOrders: 'Vyhledat objednávky',
    dateFrom: 'Datum od',
    dateTo: 'Datum do',
    search: 'Vyhledat',
    
    // Směnný kurz
    exchangeRate: 'Směnný kurz',
    updateExchangeRate: 'Změnit kurz EUR/CZK',
    enterNewRate: 'Zadejte nový kurz EUR/CZK',
    invalidRate: 'Prosím zadejte platný kurz',
    rateUpdated: 'Kurz aktualizován na',
    
    // Barcode
    barcodeScan: 'Skenovat čárový kód',
    enterBarcode: 'Zadejte čárový kód',
    
    // Chybové zprávy
    error: 'Chyba',
    errorLoading: 'Nepodařilo se načíst data',
    invalidInput: 'Neplatný vstup',
    confirmDelete: 'Opravdu chcete smazat tuto položku?',
    confirmClearCart: 'Přejete si vyprázdnit košík?',
    
    // Osoby a noci
    person: 'osoba',
    people: 'osob',
    night: 'noc',
    nights: 'nocí'
  },
  en: {
    // General
    appTitle: 'Minibar Management',
    save: 'Save',
    cancel: 'Cancel',
    confirm: 'Confirm',
    delete: 'Delete',
    close: 'Close',
    
    // Villas
    villaSelection: 'Villa Selection',
    ohYeahVilla: 'Oh Yeah Villa',
    amazingPoolVilla: 'Amazing Pool Villa',
    littleCastleVilla: 'Little Castle Villa',
    
    // Categories
    categories: 'Categories',
    all: 'All',
    nonAlcoholic: 'Non-alcoholic',
    alcoholic: 'Alcoholic',
    beer: 'Beer',
    relax: 'Relax',
    
    // Inventory
    inventory: 'Minibar Items',
    customPrice: 'Custom price',
    
    // Settings
    settings: 'Settings',
    guests: 'Number of guests',
    nights: 'Number of nights',
    currency: 'Currency',
    paymentMethod: 'Payment method',
    discount: '10% Discount',
    
    // Payment methods
    cash: 'Cash',
    card: 'Card',
    unpaid: 'Unpaid',
    
    // Overview
    overview: 'Overview',
    totalItems: 'Total items',
    totalAmount: 'Total amount',
    
    // Cart
    cart: 'Cart',
    cartEmpty: 'Cart is empty',
    addToCart: 'Add to cart',
    removeFromCart: 'Remove from cart',
    clearCart: 'Clear cart',
    total: 'Total',
    
    // Quantity
    quantity: 'Quantity',
    selectQuantity: 'Select quantity',
    enterQuantity: 'Enter quantity',
    
    // Invoice
    invoice: 'Invoice',
    generateInvoice: 'Generate invoice',
    printInvoice: 'Print invoice',
    exportToPDF: 'Export to PDF',
    date: 'Date',
    items: 'Items',
    subtotal: 'Subtotal',
    discountAmount: 'Discount',
    cityTax: 'City Tax',
    
    // Notifications
    itemAdded: 'added to cart',
    notificationSettings: 'Notification settings',
    notificationDuration: 'Notification duration',
    notificationSound: 'Sound notification',
    
    // History
    history: 'Order history',
    noHistory: 'No orders in history',
    orderDate: 'Order date',
    viewOrder: 'View order',
    deleteOrder: 'Delete order',
    searchOrders: 'Search orders',
    dateFrom: 'Date from',
    dateTo: 'Date to',
    search: 'Search',
    
    // Exchange rate
    exchangeRate: 'Exchange rate',
    updateExchangeRate: 'Update EUR/CZK rate',
    enterNewRate: 'Enter new EUR/CZK rate',
    invalidRate: 'Please enter a valid rate',
    rateUpdated: 'Rate updated to',
    
    // Barcode
    barcodeScan: 'Scan barcode',
    enterBarcode: 'Enter barcode',
    
    // Error messages
    error: 'Error',
    errorLoading: 'Failed to load data',
    invalidInput: 'Invalid input',
    confirmDelete: 'Are you sure you want to delete this item?',
    confirmClearCart: 'Do you want to clear the cart?',
    
    // Persons and nights
    person: 'person',
    people: 'people',
    night: 'night',
    nights: 'nights'
  }
};

// Aktuálně vybraný jazyk
let currentLanguage = loadLanguage();

/**
 * Načte uložený jazyk z localStorage nebo použije výchozí
 * @returns {string} Kód jazyka
 */
function loadLanguage() {
  const savedLanguage = localStorage.getItem(LANGUAGE_KEY);
  
  if (savedLanguage && AVAILABLE_LANGUAGES.includes(savedLanguage)) {
    return savedLanguage;
  }
  
  return DEFAULT_LANGUAGE;
}

/**
 * Získá aktuálně vybraný jazyk
 * @returns {string} Kód jazyka
 */
export function getCurrentLanguage() {
  return currentLanguage;
}

/**
 * Nastaví nový jazyk
 * @param {string} lang - Kód jazyka
 * @returns {boolean} True pokud byl jazyk úspěšně změněn
 */
export function setLanguage(lang) {
  if (!AVAILABLE_LANGUAGES.includes(lang)) {
    console.error(`Nepodporovaný jazyk: ${lang}`);
    return false;
  }
  
  currentLanguage = lang;
  localStorage.setItem(LANGUAGE_KEY, lang);
  
  return true;
}

/**
 * Získá překlad pro daný klíč
 * @param {string} key - Klíč překladu
 * @returns {string} Přeložený text
 */
export function translate(key) {
  const langData = translations[currentLanguage];
  
  if (!langData || !langData[key]) {
    // Pokud překlad neexistuje, zkusíme výchozí jazyk
    const defaultLangData = translations[DEFAULT_LANGUAGE];
    if (defaultLangData && defaultLangData[key]) {
      return defaultLangData[key];
    }
    
    // Pokud ani ten nemá překlad, vrátíme klíč
    return key;
  }
  
  return langData[key];
}

/**
 * Aktualizuje texty v UI podle aktuálního jazyka
 */
export function updateUILanguage() {
  // Aktualizace titulku stránky
  document.title = translate('appTitle');
  
  // Aktualizace všech elementů s data-i18n atributem
  document.querySelectorAll('[data-i18n]').forEach(element => {
    const key = element.getAttribute('data-i18n');
    if (key) {
      element.textContent = translate(key);
    }
  });
  
  // Aktualizace placeholderů
  document.querySelectorAll('[data-i18n-placeholder]').forEach(element => {
    const key = element.getAttribute('data-i18n-placeholder');
    if (key) {
      element.placeholder = translate(key);
    }
  });
}
