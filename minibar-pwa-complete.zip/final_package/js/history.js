/**
 * Modul pro správu historie objednávek
 */

/**
 * Uloží objednávku do localStorage
 * @param {Object} order - Objekt s daty objednávky
 * @returns {boolean} True pokud byla objednávka úspěšně uložena
 */
export function saveOrder(order) {
  if (!order || !order.cart || order.cart.length === 0) {
    console.error('Nelze uložit prázdnou objednávku');
    return false;
  }
  
  // Přidáme časové razítko, pokud chybí
  if (!order.date) {
    order.date = new Date();
  }
  
  try {
    // Načteme existující objednávky
    const orders = getOrders();
    
    // Přidáme novou objednávku
    orders.push(order);
    
    // Uložíme zpět do localStorage
    localStorage.setItem('orders', JSON.stringify(orders));
    
    console.log('Objednávka byla uložena do localStorage');
    return true;
  } catch (error) {
    console.error('Chyba při ukládání objednávky:', error);
    return false;
  }
}

/**
 * Načte všechny objednávky z localStorage
 * @returns {Array} Pole objednávek
 */
export function getOrders() {
  try {
    const orders = JSON.parse(localStorage.getItem('orders')) || [];
    return orders;
  } catch (error) {
    console.error('Chyba při načítání objednávek:', error);
    return [];
  }
}

/**
 * Vyhledá objednávky podle kritérií
 * @param {Object} criteria - Kritéria vyhledávání (villa, dateFrom, dateTo)
 * @returns {Array} Pole objednávek odpovídajících kritériím
 */
export function searchOrders(criteria = {}) {
  const orders = getOrders();
  
  return orders.filter(order => {
    // Filtrování podle vily
    if (criteria.villa && order.villa !== criteria.villa) {
      return false;
    }
    
    // Filtrování podle data
    if (criteria.dateFrom || criteria.dateTo) {
      const orderDate = new Date(order.date);
      
      if (criteria.dateFrom) {
        const fromDate = new Date(criteria.dateFrom);
        if (orderDate < fromDate) {
          return false;
        }
      }
      
      if (criteria.dateTo) {
        const toDate = new Date(criteria.dateTo);
        if (orderDate > toDate) {
          return false;
        }
      }
    }
    
    return true;
  });
}

/**
 * Odstraní objednávku podle indexu
 * @param {number} index - Index objednávky k odstranění
 * @returns {boolean} True pokud byla objednávka úspěšně odstraněna
 */
export function removeOrder(index) {
  try {
    const orders = getOrders();
    
    if (index < 0 || index >= orders.length) {
      console.error('Neplatný index objednávky');
      return false;
    }
    
    orders.splice(index, 1);
    localStorage.setItem('orders', JSON.stringify(orders));
    
    console.log('Objednávka byla odstraněna');
    return true;
  } catch (error) {
    console.error('Chyba při odstraňování objednávky:', error);
    return false;
  }
}

/**
 * Vymaže všechny objednávky
 * @returns {boolean} True pokud byly objednávky úspěšně vymazány
 */
export function clearOrders() {
  try {
    localStorage.removeItem('orders');
    console.log('Všechny objednávky byly vymazány');
    return true;
  } catch (error) {
    console.error('Chyba při mazání objednávek:', error);
    return false;
  }
}

/**
 * Formátuje datum objednávky do čitelného formátu
 * @param {string|Date} date - Datum objednávky
 * @returns {string} Formátované datum
 */
export function formatOrderDate(date) {
  try {
    const orderDate = new Date(date);
    return orderDate.toLocaleDateString() + ' ' + orderDate.toLocaleTimeString();
  } catch (error) {
    console.error('Chyba při formátování data:', error);
    return 'Neznámé datum';
  }
}
