/**
 * Hlavní aplikační modul pro správu minibaru
 */

import { formatPrice, getCategoryIcon, getPaymentMethodName } from './utils.js';
import { getVillaInventory, resetInventoryCache } from './inventory.js';
import * as cartModule from './cart.js';

// Globální proměnné aplikace
let selectedVilla = "oh-yeah"; // Výchozí vila
let exchangeRate = 24.5; // Výchozí kurz EUR/CZK
const CITY_TAX_PER_PERSON_PER_NIGHT = 2; // 2 EUR na osobu na noc

// Nastavení pro notifikace
let notificationDuration = 2000; // Výchozí doba zobrazení notifikace (ms)
let notificationSound = false; // Výchozí nastavení zvuku notifikace

// Po načtení stránky inicializujeme aplikaci
document.addEventListener("DOMContentLoaded", async function() {
    // Nastavíme event listenery pro vily
    setupVillaListeners();
    
    // Zvýrazníme vybranou vilu
    highlightSelectedVilla();
    
    // Načteme položky inventáře pro výchozí vilu
    await loadInventory();
    
    // Nastavíme event listenery pro kategorie
    setupCategoryListeners();
    
    // Nastavíme event listenery pro počet hostů a nocí
    setupGuestsAndNightsListeners();
    
    // Načteme uložené objednávky z localStorage
    loadOrdersFromStorage();
    
    // Načteme aktuální kurz z API (pokud je dostupný)
    fetchExchangeRate();
    
    // Aktualizujeme statistiky v přehledu
    updateStats();
});

// Nastavení posluchačů událostí pro počet hostů a nocí
function setupGuestsAndNightsListeners() {
    const guestsInput = document.getElementById('guests');
    const nightsInput = document.getElementById('nights');
    
    if (guestsInput) {
        guestsInput.addEventListener('change', function() {
            updateStats();
        });
    }
    
    if (nightsInput) {
        nightsInput.addEventListener('change', function() {
            updateStats();
        });
    }
}

// Nastavení posluchačů událostí pro tlačítka vil
function setupVillaListeners() {
    document.querySelectorAll(".villa-btn").forEach(btn => {
        btn.addEventListener("click", function() {
            const villa = this.classList.contains("oh-yeah") ? "oh-yeah" 
                        : this.classList.contains("amazing-pool") ? "amazing-pool"
                        : "little-castle";
            
            selectVilla(villa);
        });
    });
}

// Funkce pro výběr vily
async function selectVilla(villa) {
    selectedVilla = villa;
    highlightSelectedVilla();
    await loadInventory();
}

// Zvýraznění vybrané vily
function highlightSelectedVilla() {
    // Odebereme třídu "active" ze všech tlačítek vil
    document.querySelectorAll(".villa-btn").forEach(btn => {
        btn.classList.remove("active");
    });
    
    // Přidáme třídu "active" vybranému tlačítku
    const selectedBtn = document.querySelector(`.villa-btn.${selectedVilla}`);
    if (selectedBtn) {
        selectedBtn.classList.add("active");
    }
}

// Nastavení event listenerů pro kategorie
function setupCategoryListeners() {
    document.querySelectorAll('.category-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            // Odebereme třídu active ze všech tabů
            document.querySelectorAll('.category-tab').forEach(t => {
                t.classList.remove('active');
            });
            
            // Přidáme třídu active kliknutému tabu
            this.classList.add('active');
            
            // Načteme položky pro vybranou kategorii
            loadInventory();
        });
    });

    // Nastavení poslouchače události pro input množství
    const quantityInput = document.getElementById('quantityInput');
    if (quantityInput) {
        quantityInput.addEventListener('change', function() {
            // Zajistíme, že hodnota je minimálně 1 (pokud není prázdná)
            if (this.value && parseInt(this.value) < 1) {
                this.value = 1;
            }
            cartModule.setSelectedQuantity(parseInt(this.value) || 1);
        });
    }
}

// Načtení položek inventáře podle vybrané vily a aktuální kategorie
async function loadInventory() {
    const inventoryContainer = document.getElementById("inventory");
    if (!inventoryContainer) {
        console.error("Element #inventory nebyl nalezen");
        return;
    }
    
    inventoryContainer.innerHTML = "";
    
    // Získáme aktuální kategorii
    const activeTab = document.querySelector(".category-tab.active");
    if (!activeTab) {
        console.error("Žádná aktivní kategorie nebyla nalezena");
        return;
    }
    
    const activeCategory = activeTab.dataset.category;
    
    try {
        // Načteme inventář pro vybranou vilu a kategorii
        const villaInventory = await getVillaInventory(selectedVilla, activeCategory);
        
        // Přidáme položky do kontejneru
        villaInventory.forEach(item => {
            const itemElement = createItemElement(item);
            inventoryContainer.appendChild(itemElement);
        });
    } catch (error) {
        console.error("Chyba při načítání inventáře:", error);
        inventoryContainer.innerHTML = "<p>Nepodařilo se načíst inventář. Zkuste to prosím znovu.</p>";
    }
}

// Vytvoření HTML elementu pro položku inventáře
function createItemElement(item) {
    const itemElement = document.createElement("div");
    itemElement.className = `item ${selectedVilla}`;
    
    // Přidáme obrázek nebo ikonu
    if (item.image) {
        // Nejprve zkontrolujeme, zda existuje obrázek
        const img = document.createElement("img");
        img.src = item.image;
        img.className = "item-image";
        img.alt = item.name;
        img.loading = "lazy"; // Přidáme lazy loading pro obrázky
        img.onerror = function() {
            // Pokud obrázek neexistuje, nahradíme ho ikonou
            this.onerror = null;
            this.remove();
            const icon = document.createElement("i");
            icon.className = `item-icon fas ${getCategoryIcon(item.category)}`;
            itemElement.insertBefore(icon, itemElement.firstChild);
        };
        itemElement.appendChild(img);
    } else {
        const icon = document.createElement("i");
        icon.className = `item-icon fas ${getCategoryIcon(item.category)}`;
        itemElement.appendChild(icon);
    }
    
    // Název položky
    const nameElement = document.createElement("div");
    nameElement.className = "item-name";
    nameElement.textContent = item.name;
    itemElement.appendChild(nameElement);
    
    // Cena položky
    const priceElement = document.createElement("div");
    priceElement.className = "item-price";
    
    // Formátování ceny podle měny
    const formattedPrice = item.customPrice 
        ? "Vlastní cena"
        : formatPrice(item.price, item.currency);
    
    priceElement.textContent = formattedPrice;
    itemElement.appendChild(priceElement);
    
    // Event listener pro kliknutí na položku
    itemElement.addEventListener("click", function() {
        selectItem(item);
    });
    
    return itemElement;
}

// Funkce pro výběr položky
function selectItem(item) {
    cartModule.setSelectedItem(item, 1);
    
    // Zobrazení a nastavení selektoru množství
    const selectedItemNameEl = document.getElementById("selectedItemName");
    const selectedItemPriceEl = document.getElementById("selectedItemPrice");
    if (selectedItemNameEl) selectedItemNameEl.textContent = item.name;
    if (selectedItemPriceEl) {
        selectedItemPriceEl.textContent = item.customPrice 
            ? "Vlastní cena"
            : formatPrice(item.price, item.currency);
    }
    
    // Resetujeme input pro množství - nastavíme na prázdné pole
    const quantityInput = document.getElementById('quantityInput');
    if (quantityInput) {
        quantityInput.value = "";
        quantityInput.placeholder = "Zadejte množství";
        quantityInput.focus(); // Automaticky zaměříme na pole pro množství
    }
    
    // Zobrazení selektoru množství
    const quantitySelector = document.getElementById("quantitySelector");
    if (quantitySelector) {
        quantitySelector.style.display = "flex";
    }
}

// Skrytí selektoru množství
function hideQuantitySelector() {
    const quantitySelector = document.getElementById("quantitySelector");
    if (quantitySelector) {
        quantitySelector.style.display = "none";
    }
}

// Funkce potvrzení množství a přidání do košíku
function confirmQuantity() {
    const selectedItem = cartModule.getSelectedItem();
    if (!selectedItem) return;
    
    // Získáme množství z inputu
    const quantityInput = document.getElementById('quantityInput');
    let selectedQuantity = 1;
    if (quantityInput) {
        selectedQuantity = parseInt(quantityInput.value) || 1;
    }
    
    // Přidáme položku do košíku
    const added = cartModule.addToCart(selectedItem, selectedQuantity);
    
    if (added) {
        // Skryjeme selektor množství
        hideQuantitySelector();
        
        // Aktualizujeme statistiky
        updateStats();
        
        // Najdeme element položky a přidáme animaci
        const itemElements = document.querySelectorAll('.item');
        let itemElement = null;
        
        for (const el of itemElements) {
            if (el.querySelector('.item-name').textContent === selectedItem.name) {
                itemElement = el;
                break;
            }
        }
        
        if (itemElement) {
            itemElement.classList.add('added-to-cart');
            setTimeout(() => itemElement.classList.remove('added-to-cart'), 1000);
        }
        
        // Zobrazíme notifikaci o přidání do košíku
        const itemName = selectedItem.name;
        const message = `${itemName} (${selectedQuantity}x) přidáno do košíku`;
        
        // Vytvoříme dočasnou notifikaci
        showNotification(message, notificationDuration, notificationSound);
    }
}

// Funkce pro zobrazení notifikace
function showNotification(message, duration = 2000, playSound = false) {
    // Kontrola, zda již existuje notifikace
    let notification = document.getElementById("cart-notification");
    
    // Pokud neexistuje, vytvoříme ji
    if (!notification) {
        notification = document.createElement("div");
        notification.id = "cart-notification";
        notification.style.position = "fixed";
        notification.style.bottom = "20px";
        notification.style.left = "50%";
        notification.style.transform = "translateX(-50%)";
        notification.style.backgroundColor = "var(--primary-color)";
        notification.style.color = "white";
        notification.style.padding = "10px 20px";
        notification.style.borderRadius = "5px";
        notification.style.boxShadow = "0 2px 8px rgba(0,0,0,0.2)";
        notification.style.zIndex = "9000";
        notification.style.fontSize = "14px";
        notification.style.fontWeight = "bold";
        notification.style.textAlign = "center";
        notification.style.opacity = "0";
        notification.style.transition = "opacity 0.3s ease";
        notification.style.display = "flex";
        notification.style.alignItems = "center";
        notification.style.gap = "10px";
        
        document.body.appendChild(notification);
    }
    
    // Přidáme ikonu úspěchu
    notification.innerHTML = `<i class="fas fa-check-circle"></i> ${message}`;
    
    // Přehrajeme zvuk, pokud je povoleno
    if (playSound) {
        const audio = new Audio('/sounds/notification.mp3');
        audio.play().catch(e => console.log('Zvuk notifikace nelze přehrát:', e));
    }
    
    // Zobrazíme notifikaci s animací
    setTimeout(() => {
        notification.style.opacity = "1";
    }, 10);
    
    // Skryjeme notifikaci po uplynutí časového limitu
    setTimeout(() => {
        notification.style.opacity = "0";
    }, duration);
}

// Výpočet city tax (2 EUR na osobu na noc)
function calculateCityTax() {
    const guestsEl = document.getElementById("guests");
    const nightsEl = document.getElementById("nights");
    
    if (!guestsEl || !nightsEl) return 0;
    
    const guests = parseInt(guestsEl.value) || 1;
    const nights = parseInt(nightsEl.value) || 1;
    
    return guests * nights * CITY_TAX_PER_PERSON_PER_NIGHT;
}

// Aktualizace statistik
function updateStats() {
    // Počet položek v košíku
    const totalItems = cartModule.getCartItemCount();
    const totalItemsEl = document.getElementById("totalItems");
    const cartCountEl = document.getElementById("cartCount");
    
    if (totalItemsEl) totalItemsEl.textContent = totalItems;
    if (cartCountEl) cartCountEl.textContent = totalItems;
    
    // Celková částka
    const currencyEl = document.getElementById("currency");
    if (!currencyEl) return;
    
    const currency = currencyEl.value;
    const itemsTotal = cartModule.calculateTotalAmount(currency, exchangeRate);
    
    // Zjistíme, zda je aktivní sleva
    const discountEl = document.getElementById("discount");
    const discount = discountEl ? discountEl.checked : false;
    
    // Výpočet city tax v aktuální měně
    let cityTax = calculateCityTax();
    if (currency === 'CZK') {
        cityTax = cityTax * exchangeRate;
    }
    
    // Aplikujeme slevu pouze na položky z minibaru, ne na city tax
    let finalItemsAmount = discount ? itemsTotal * 0.9 : itemsTotal;
    
    // Celková částka = položky + city tax
    const finalTotal = finalItemsAmount + cityTax;
    
    const totalAmountEl = document.getElementById("totalAmount");
    if (totalAmountEl) {
        totalAmountEl.textContent = formatPrice(finalTotal, currency);
    }
    
    // Aktualizujeme také celkovou částku v košíku
    updateCartTotal(cityTax);
}

// Přepínání zobrazení košíku
function toggleCart(forceShow = false) {
    const cartPanel = document.getElementById("cartPanel");
    if (!cartPanel) return;
    
    if (forceShow) {
        cartPanel.classList.add("active");
    } else {
        cartPanel.classList.toggle("active");
    }
    
    if (cartPanel.classList.contains("active")) {
        renderCartItems();
        document.body.style.overflow = 'hidden'; // Zamezí scrollování na pozadí
    } else {
        document.body.style.overflow = ''; // Obnoví scrollování
    }
}

// Vykreslení položek v košíku
function renderCartItems() {
    const cartItemsContainer = document.getElementById("cartItems");
    if (!cartItemsContainer) return;
    
    cartItemsContainer.innerHTML = "";
    
    const cart = cartModule.getCart();
    
    if (cart.length === 0) {
        cartItemsContainer.innerHTML = "<p style='text-align: center; padding: 20px;'>Košík je prázdný</p>";
        
        // Aktualizujeme celkovou částku
        updateCartTotal();
        return;
    }
    
    // Vytvoříme položky košíku
    cart.forEach((item, index) => {
        const cartItem = document.createElement("div");
        cartItem.className = "cart-item";
        
        const itemInfo = document.createElement("div");
        itemInfo.style.display = "flex";
        itemInfo.style.alignItems = "center";
        
        const quantityBadge = document.createElement("span");
        quantityBadge.className = "cart-item-quantity";
        quantityBadge.textContent = item.quantity + "x";
        itemInfo.appendChild(quantityBadge);
        
        const itemName = document.createElement("span");
        itemName.textContent = item.name;
        itemInfo.appendChild(itemName);
        
        cartItem.appendChild(itemInfo);
        
        const itemActions = document.createElement("div");
        itemActions.style.display = "flex";
        itemActions.style.alignItems = "center";
        itemActions.style.gap = "10px";
        
        const itemPrice = document.createElement("span");
        itemPrice.textContent = formatPrice(item.price * item.quantity, item.currency);
        itemActions.appendChild(itemPrice);
        
        const removeButton = document.createElement("button");
        removeButton.className = "cart-item-remove";
        removeButton.innerHTML = '<i class="fas fa-trash"></i>';
        removeButton.addEventListener("click", (e) => {
            e.stopPropagation(); // Zabraňuje bubblování události
            removeCartItem(index);
        });
        itemActions.appendChild(removeButton);
        
        cartItem.appendChild(itemActions);
        
        cartItemsContainer.appendChild(cartItem);
    });
    
    // Přidání položky city tax
    addCityTaxToCart(cartItemsContainer);
    
    // Aktualizujeme celkovou částku
    updateCartTotal();
}

// Přidání položky city tax do košíku
function addCityTaxToCart(container) {
    // Získáme počet hostů a nocí
    const guestsEl = document.getElementById("guests");
    const nightsEl = document.getElementById("nights");
    const currencyEl = document.getElementById("currency");
    
    if (!guestsEl || !nightsEl || !currencyEl) return;
    
    const guests = parseInt(guestsEl.value) || 1;
    const nights = parseInt(nightsEl.value) || 1;
    const currency = currencyEl.value;
    
    // Výpočet city tax
    let cityTaxAmount = guests * nights * CITY_TAX_PER_PERSON_PER_NIGHT;
    let taxCurrency = 'EUR';
    
    // Převod na aktuální měnu
    if (currency === 'CZK') {
        cityTaxAmount = cityTaxAmount * exchangeRate;
        taxCurrency = 'CZK';
    }
    
    // Vytvoření položky city tax
    const taxItem = document.createElement("div");
    taxItem.className = "cart-item city-tax";
    taxItem.style.background = "#f0f0f0";
    taxItem.style.fontStyle = "italic";
    
    const taxInfo = document.createElement("div");
    
    const taxLabel = document.createElement("span");
    taxLabel.textContent = `City Tax (${guests} ${guests > 1 ? 'osob' : 'osoba'} × ${nights} ${nights > 1 ? 'nocí' : 'noc'} × 2 EUR)`;
    taxInfo.appendChild(taxLabel);
    
    taxItem.appendChild(taxInfo);
    
    const taxPrice = document.createElement("div");
    taxPrice.textContent = formatPrice(cityTaxAmount, taxCurrency);
    
    taxItem.appendChild(taxPrice);
    
    container.appendChild(taxItem);
}

// Aktualizace celkové částky v košíku
function updateCartTotal(cityTax) {
    const cartTotalElement = document.getElementById("cartTotal");
    if (!cartTotalElement) return;
    
    const currencyEl = document.getElementById("currency");
    if (!currencyEl) return;
    
    const currency = currencyEl.value;
    const itemsTotal = cartModule.calculateTotalAmount(currency, exchangeRate);
    
    const discountEl = document.getElementById("discount");
    const discount = discountEl ? discountEl.checked : false;
    
    // Pokud city tax není zadáno, vypočítáme ji
    if (cityTax === undefined) {
        cityTax = calculateCityTax();
        if (currency === 'CZK') {
            cityTax = cityTax * exchangeRate;
        }
    }
    
    // Aplikujeme slevu pouze na položky, ne na city tax
    const finalItemsAmount = discount ? itemsTotal * 0.9 : itemsTotal;
    const finalTotal = finalItemsAmount + cityTax;
    
    // Aktualizujeme zobrazení v košíku
    cartTotalElement.textContent = formatPrice(finalTotal, currency);
}

// Odstranění položky z košíku
function removeCartItem(index) {
    if (cartModule.removeFromCart(index)) {
        renderCartItems();
        updateStats();
    }
}

// Generování faktury
function generateInvoice() {
    const cart = cartModule.getCart();
    if (cart.length === 0) {
        alert("Košík je prázdný. Přidejte prosím položky do košíku.");
        return;
    }

    const invoiceModal = document.getElementById("invoiceModal");
    const invoiceContent = document.getElementById("invoiceContent");
    if (!invoiceModal || !invoiceContent) return;
    
    // Základní informace
    const currencyEl = document.getElementById("currency");
    const guestsEl = document.getElementById("guests");
    const nightsEl = document.getElementById("nights");
    const paymentMethodEl = document.getElementById("paymentMethod");
    const discountEl = document.getElementById("discount");
    
    if (!currencyEl || !guestsEl || !nightsEl || !paymentMethodEl) return;
    
    const currency = currencyEl.value;
    const guests = guestsEl.value;
    const nights = nightsEl.value;
    const paymentMethod = paymentMethodEl.value;
    const discount = discountEl ? discountEl.checked : false;
    
    // Celková částka položek
    const itemsSubtotal = cartModule.calculateTotalAmount(currency, exchangeRate);
    
    // City tax
    let cityTax = guests * nights * CITY_TAX_PER_PERSON_PER_NIGHT;
    if (currency === 'CZK') {
        cityTax = cityTax * exchangeRate;
    }
    
    // Sleva (pouze na položky, ne na city tax)
    const itemsDiscount = discount ? itemsSubtotal * 0.1 : 0;
    const itemsTotal = itemsSubtotal - itemsDiscount;
    
    // Celková částka včetně city tax
    const finalTotal = itemsTotal + cityTax;
    
    // Vytvoření obsahu faktury
    let invoiceHTML = `
        <div class="invoice-header">
            <h2>${selectedVilla.charAt(0).toUpperCase() + selectedVilla.slice(1).replace('-', ' ')} Villa</h2>
            <p>Datum: ${new Date().toLocaleDateString()}</p>
            <p>Hosté: ${guests} | Nocí: ${nights}</p>
        </div>
        <div class="invoice-items">
            <h3>Položky:</h3>
    `;
    
    // Přidáme položky
    cart.forEach(item => {
        let itemAmount = item.price * item.quantity;
        
        // Převod na cílovou měnu, pokud je to potřeba
        if (item.currency !== currency) {
            if (item.currency === 'CZK' && currency === 'EUR') {
                itemAmount = itemAmount / exchangeRate;
            } else if (item.currency === 'EUR' && currency === 'CZK') {
                itemAmount = itemAmount * exchangeRate;
            }
        }
        
        invoiceHTML += `
            <div class="invoice-item">
                <div>
                    <span class="cart-item-quantity">${item.quantity}x</span>
                    ${item.name}
                </div>
                <div>${formatPrice(itemAmount, currency)}</div>
            </div>
        `;
    });
    
    // City tax
    invoiceHTML += `
        <div class="invoice-item" style="font-style: italic; margin-top: 10px;">
            <div>
                City Tax (${guests} ${guests > 1 ? 'osob' : 'osoba'} × ${nights} ${nights > 1 ? 'nocí' : 'noc'} × 2 EUR)
            </div>
            <div>${formatPrice(cityTax, currency)}</div>
        </div>
    `;
    
    // Celkové shrnutí
    invoiceHTML += `
        <div class="subtotal">Mezisoučet za položky: ${formatPrice(itemsSubtotal, currency)}</div>
    `;
    
    if (discount) {
        invoiceHTML += `
            <div class="discount">Sleva 10% (pouze na položky): -${formatPrice(itemsDiscount, currency)}</div>
        `;
    }
    
    invoiceHTML += `
        <div class="subtotal">Položky po slevě: ${formatPrice(itemsTotal, currency)}</div>
        <div class="subtotal">City Tax: ${formatPrice(cityTax, currency)}</div>
    `;
    
    // Celková částka a způsob platby
    invoiceHTML += `
        <div class="total">Celkem: ${formatPrice(finalTotal, currency)}</div>
        <div class="payment-method">Způsob platby: ${getPaymentMethodName(paymentMethod)}</div>
        <div class="invoice-actions">
            <button class="print-btn" onclick="printInvoice()">Tisk faktury</button>
            <button class="export-btn" onclick="exportToPDF()">Export do PDF</button>
            <button class="close-btn" onclick="closeInvoice()">Zavřít</button>
        </div>
    `;
    
    // Nastavíme obsah a zobrazíme fakturu
    invoiceContent.innerHTML = invoiceHTML;
    invoiceModal.style.display = "flex";
}

// Tisk faktury
function printInvoice() {
    window.print();
}

// Zavření faktury
function closeInvoice() {
    const invoiceModal = document.getElementById("invoiceModal");
    if (invoiceModal) {
        invoiceModal.style.display = "none";
    }
}

// Funkce pro dokončení objednávky
function checkout() {
    const cart = cartModule.getCart();
    if (cart.length === 0) {
        alert("Košík je prázdný. Přidejte prosím položky do košíku.");
        return;
    }
    
    // Generujeme fakturu
    generateInvoice();
    
    // Uložíme objednávku do localStorage
    saveOrder();
    
    // Po vytvoření objednávky bychom mohli resetovat košík
    if (confirm("Přejete si po vytvoření objednávky vyprázdnit košík?")) {
        cartModule.clearCart();
        updateStats();
        toggleCart(); // Skryjeme košík
    }
}

// Uložení objednávky do localStorage
function saveOrder() {
    const cart = cartModule.getCart();
    if (cart.length === 0) return;
    
    const currencyEl = document.getElementById("currency");
    const guestsEl = document.getElementById("guests");
    const nightsEl = document.getElementById("nights");
    const paymentMethodEl = document.getElementById("paymentMethod");
    
    if (!currencyEl || !guestsEl || !nightsEl || !paymentMethodEl) return;
    
    const order = {
        cart: cart,
        date: new Date(),
        villa: selectedVilla,
        guests: parseInt(guestsEl.value) || 1,
        nights: parseInt(nightsEl.value) || 1,
        currency: currencyEl.value,
        paymentMethod: paymentMethodEl.value,
        exchangeRate: exchangeRate
    };
    
    // Načteme existující objednávky
    const orders = JSON.parse(localStorage.getItem('orders')) || [];
    
    // Přidáme novou objednávku
    orders.push(order);
    
    // Uložíme zpět do localStorage
    localStorage.setItem('orders', JSON.stringify(orders));
    
    console.log('Objednávka byla uložena do localStorage');
}

// Načtení objednávek z localStorage
function loadOrdersFromStorage() {
    const orders = JSON.parse(localStorage.getItem('orders')) || [];
    console.log(`Načteno ${orders.length} objednávek z localStorage`);
    return orders;
}

// Aktualizace směnného kurzu
function updateExchangeRate() {
    const newRate = prompt("Zadejte nový kurz EUR/CZK:", exchangeRate);
    if (newRate === null) return;
    
    const parsedRate = parseFloat(newRate);
    if (isNaN(parsedRate) || parsedRate <= 0) {
        alert("Prosím zadejte platný kurz.");
        return;
    }
    
    exchangeRate = parsedRate;
    updateStats();
    alert(`Kurz aktualizován na 1 EUR = ${exchangeRate} CZK`);
}

// Načtení aktuálního kurzu z API
async function fetchExchangeRate() {
    try {
        const response = await fetch('https://api.exchangerate-api.com/v4/latest/EUR');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        if (data.rates && data.rates.CZK) {
            exchangeRate = data.rates.CZK;
            console.log(`Kurz aktualizován z API: 1 EUR = ${exchangeRate} CZK`);
            updateStats();
        }
    } catch (error) {
        console.error('Chyba při načítání kurzu:', error);
    }
}

// Export faktury do PDF
function exportToPDF() {
    alert('Funkce exportu do PDF bude implementována v další verzi.');
}

// Nastavení doby zobrazení notifikace
function setNotificationDuration(duration) {
    notificationDuration = duration;
}

// Nastavení zvuku notifikace
function setNotificationSound(enabled) {
    notificationSound = enabled;
}

// Skenování čárového kódu
function scanBarcode() {
    const barcodeInput = document.getElementById('barcodeInput');
    if (!barcodeInput) return;
    
    const barcode = barcodeInput.value;
    if (!barcode) return;
    
    // Zde by byla implementace vyhledávání položky podle čárového kódu
    alert(`Funkce skenování čárového kódu bude implementována v další verzi. Naskenovaný kód: ${barcode}`);
    
    // Resetujeme input
    barcodeInput.value = '';
}

// Exportujeme funkce pro použití v HTML
window.selectVilla = selectVilla;
window.toggleCart = toggleCart;
window.confirmQuantity = confirmQuantity;
window.hideQuantitySelector = hideQuantitySelector;
window.generateInvoice = generateInvoice;
window.printInvoice = printInvoice;
window.closeInvoice = closeInvoice;
window.checkout = checkout;
window.updateExchangeRate = updateExchangeRate;
window.exportToPDF = exportToPDF;
window.scanBarcode = scanBarcode;
window.updateStats = updateStats;
