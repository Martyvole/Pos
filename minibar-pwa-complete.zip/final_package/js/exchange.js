/**
 * Modul pro správu směnných kurzů
 */

// Výchozí směnný kurz EUR/CZK
const DEFAULT_EXCHANGE_RATE = 24.5;

// Klíč pro uložení kurzu v localStorage
const EXCHANGE_RATE_KEY = 'exchangeRate';

// Klíč pro uložení času poslední aktualizace
const LAST_UPDATE_KEY = 'lastExchangeRateUpdate';

// Interval pro automatickou aktualizaci (24 hodin v ms)
const UPDATE_INTERVAL = 86400000;

// URL pro získání aktuálního kurzu
const EXCHANGE_API_URL = 'https://api.exchangerate-api.com/v4/latest/EUR';

/**
 * Načte směnný kurz z localStorage nebo použije výchozí hodnotu
 * @returns {number} Směnný kurz EUR/CZK
 */
export function getExchangeRate() {
  const savedRate = localStorage.getItem(EXCHANGE_RATE_KEY);
  return savedRate ? parseFloat(savedRate) : DEFAULT_EXCHANGE_RATE;
}

/**
 * Uloží směnný kurz do localStorage
 * @param {number} rate - Nový směnný kurz
 * @returns {boolean} True pokud byl kurz úspěšně uložen
 */
export function saveExchangeRate(rate) {
  if (isNaN(rate) || rate <= 0) {
    console.error('Neplatný směnný kurz');
    return false;
  }
  
  try {
    localStorage.setItem(EXCHANGE_RATE_KEY, rate.toString());
    localStorage.setItem(LAST_UPDATE_KEY, Date.now().toString());
    return true;
  } catch (error) {
    console.error('Chyba při ukládání směnného kurzu:', error);
    return false;
  }
}

/**
 * Načte aktuální kurz z API
 * @param {boolean} forceUpdate - Vynutit aktualizaci i když není potřeba
 * @returns {Promise<number>} Aktuální směnný kurz
 */
export async function fetchExchangeRate(forceUpdate = false) {
  // Kontrola, zda je potřeba aktualizovat kurz
  if (!forceUpdate) {
    const lastUpdate = localStorage.getItem(LAST_UPDATE_KEY);
    if (lastUpdate && Date.now() - parseInt(lastUpdate) < UPDATE_INTERVAL) {
      console.log('Kurz byl nedávno aktualizován, používám uložený kurz');
      return getExchangeRate();
    }
  }
  
  try {
    console.log('Načítám aktuální kurz z API...');
    const response = await fetch(EXCHANGE_API_URL);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const data = await response.json();
    
    if (data.rates && data.rates.CZK) {
      const newRate = data.rates.CZK;
      saveExchangeRate(newRate);
      console.log(`Kurz aktualizován z API: 1 EUR = ${newRate} CZK`);
      return newRate;
    } else {
      throw new Error('API nevrátilo očekávaná data');
    }
  } catch (error) {
    console.error('Chyba při načítání kurzu:', error);
    return getExchangeRate(); // Vrátíme uložený nebo výchozí kurz
  }
}

/**
 * Manuální aktualizace směnného kurzu
 * @param {number} newRate - Nový směnný kurz
 * @returns {boolean} True pokud byl kurz úspěšně aktualizován
 */
export function updateExchangeRate(newRate) {
  if (isNaN(newRate) || newRate <= 0) {
    console.error('Neplatný směnný kurz');
    return false;
  }
  
  return saveExchangeRate(newRate);
}

/**
 * Nastaví automatickou aktualizaci kurzu
 * @param {Function} callback - Funkce, která se zavolá po aktualizaci kurzu
 */
export function setupAutomaticUpdate(callback) {
  // Nejprve zkontrolujeme, zda je potřeba aktualizovat kurz
  const lastUpdate = localStorage.getItem(LAST_UPDATE_KEY);
  const currentTime = Date.now();
  
  if (!lastUpdate || currentTime - parseInt(lastUpdate) >= UPDATE_INTERVAL) {
    // Pokud je potřeba aktualizovat, uděláme to hned
    fetchExchangeRate(true).then(rate => {
      if (callback && typeof callback === 'function') {
        callback(rate);
      }
    });
  }
  
  // Nastavíme interval pro pravidelnou aktualizaci
  setInterval(() => {
    fetchExchangeRate(true).then(rate => {
      if (callback && typeof callback === 'function') {
        callback(rate);
      }
    });
  }, UPDATE_INTERVAL);
}
