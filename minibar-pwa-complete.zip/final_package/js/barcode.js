/**
 * Modul pro skenování čárových kódů
 */

// Knihovna QuaggaJS pro skenování čárových kódů
// Poznámka: V reálném nasazení by bylo potřeba nainstalovat knihovnu QuaggaJS
// npm install quagga

/**
 * Inicializuje skener čárových kódů
 * @param {string} containerId - ID elementu, ve kterém bude skener
 * @param {Function} callback - Funkce, která se zavolá po úspěšném skenování
 */
export function initBarcodeScanner(containerId, callback) {
  // Kontrola, zda je dostupná knihovna Quagga
  if (typeof Quagga === 'undefined') {
    console.error('Knihovna QuaggaJS není načtena');
    return false;
  }
  
  const container = document.getElementById(containerId);
  if (!container) {
    console.error(`Element s ID ${containerId} nebyl nalezen`);
    return false;
  }
  
  // Konfigurace skeneru
  Quagga.init({
    inputStream: {
      name: "Live",
      type: "LiveStream",
      target: container,
      constraints: {
        width: 640,
        height: 480,
        facingMode: "environment" // Použití zadní kamery na mobilních zařízeních
      }
    },
    locator: {
      patchSize: "medium",
      halfSample: true
    },
    numOfWorkers: 2,
    decoder: {
      readers: ["ean_reader", "ean_8_reader", "code_128_reader", "code_39_reader", "code_93_reader"]
    },
    locate: true
  }, function(err) {
    if (err) {
      console.error('Chyba při inicializaci skeneru:', err);
      return;
    }
    
    console.log('Skener čárových kódů byl inicializován');
    
    // Spustíme skener
    Quagga.start();
    
    // Nastavíme callback pro detekci čárového kódu
    Quagga.onDetected(function(result) {
      const code = result.codeResult.code;
      console.log('Detekován čárový kód:', code);
      
      // Zastavíme skener
      Quagga.stop();
      
      // Zavoláme callback s naskenovaným kódem
      if (callback && typeof callback === 'function') {
        callback(code);
      }
    });
  });
  
  return true;
}

/**
 * Zastaví skener čárových kódů
 */
export function stopBarcodeScanner() {
  if (typeof Quagga !== 'undefined') {
    Quagga.stop();
    console.log('Skener čárových kódů byl zastaven');
    return true;
  }
  
  return false;
}

/**
 * Simuluje skenování čárového kódu (pro testování)
 * @param {string} barcode - Čárový kód k simulaci
 * @param {Function} callback - Funkce, která se zavolá po simulaci
 */
export function simulateBarcodeScanning(barcode, callback) {
  console.log('Simulace skenování čárového kódu:', barcode);
  
  // Simulujeme zpoždění skenování
  setTimeout(() => {
    if (callback && typeof callback === 'function') {
      callback(barcode);
    }
  }, 500);
  
  return true;
}

/**
 * Vyhledá položku podle čárového kódu
 * @param {string} barcode - Čárový kód
 * @param {Array} inventory - Inventář položek
 * @returns {Object|null} Nalezená položka nebo null
 */
export function findItemByBarcode(barcode, inventory) {
  if (!barcode || !inventory || !Array.isArray(inventory)) {
    return null;
  }
  
  // Vyhledáme položku podle čárového kódu
  return inventory.find(item => item.barcode === barcode) || null;
}

/**
 * Zpracuje naskenovaný čárový kód
 * @param {string} barcode - Naskenovaný čárový kód
 * @param {Array} inventory - Inventář položek
 * @param {Function} onItemFound - Funkce, která se zavolá, když je položka nalezena
 * @param {Function} onItemNotFound - Funkce, která se zavolá, když položka není nalezena
 */
export function processBarcodeScanning(barcode, inventory, onItemFound, onItemNotFound) {
  console.log('Zpracování čárového kódu:', barcode);
  
  const item = findItemByBarcode(barcode, inventory);
  
  if (item) {
    console.log('Nalezena položka:', item.name);
    
    if (onItemFound && typeof onItemFound === 'function') {
      onItemFound(item);
    }
  } else {
    console.log('Položka nebyla nalezena');
    
    if (onItemNotFound && typeof onItemNotFound === 'function') {
      onItemNotFound(barcode);
    }
  }
}
