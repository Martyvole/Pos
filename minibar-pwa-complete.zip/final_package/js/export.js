/**
 * Modul pro export dat do PDF
 */

// Poznámka: V reálném nasazení by bylo potřeba nainstalovat knihovnu jsPDF
// npm install jspdf

/**
 * Exportuje fakturu do PDF
 * @param {Object} invoiceData - Data faktury
 * @returns {boolean} True pokud byl export úspěšný
 */
export function exportInvoiceToPDF(invoiceData) {
  // Kontrola, zda je dostupná knihovna jsPDF
  if (typeof jsPDF === 'undefined') {
    console.error('Knihovna jsPDF není načtena');
    return false;
  }
  
  try {
    // Vytvoříme nový PDF dokument
    const doc = new jsPDF();
    
    // Nastavíme základní vlastnosti
    doc.setFont('helvetica');
    doc.setFontSize(16);
    
    // Přidáme hlavičku faktury
    doc.text(`${invoiceData.villa} Villa`, 105, 20, { align: 'center' });
    doc.setFontSize(12);
    doc.text(`Datum: ${new Date(invoiceData.date).toLocaleDateString()}`, 105, 30, { align: 'center' });
    doc.text(`Hosté: ${invoiceData.guests} | Nocí: ${invoiceData.nights}`, 105, 40, { align: 'center' });
    
    // Přidáme položky
    doc.setFontSize(14);
    doc.text('Položky:', 20, 60);
    
    let y = 70;
    
    // Přidáme hlavičku tabulky
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('Položka', 20, y);
    doc.text('Množství', 120, y);
    doc.text('Cena', 160, y);
    doc.setFont('helvetica', 'normal');
    
    y += 10;
    
    // Přidáme položky faktury
    invoiceData.cart.forEach(item => {
      doc.text(item.name, 20, y);
      doc.text(item.quantity.toString(), 120, y);
      doc.text(`${(item.price * item.quantity).toFixed(2)} ${item.currency}`, 160, y);
      y += 10;
      
      // Pokud se blížíme ke konci stránky, přidáme novou
      if (y > 270) {
        doc.addPage();
        y = 20;
      }
    });
    
    // Přidáme city tax
    y += 5;
    doc.setFont('helvetica', 'italic');
    doc.text(`City Tax (${invoiceData.guests} ${invoiceData.guests > 1 ? 'osob' : 'osoba'} × ${invoiceData.nights} ${invoiceData.nights > 1 ? 'nocí' : 'noc'} × 2 EUR)`, 20, y);
    doc.text(`${invoiceData.cityTax.toFixed(2)} ${invoiceData.currency}`, 160, y);
    doc.setFont('helvetica', 'normal');
    
    // Přidáme shrnutí
    y += 15;
    doc.text(`Mezisoučet za položky: ${invoiceData.subtotal.toFixed(2)} ${invoiceData.currency}`, 20, y);
    
    // Pokud je aplikována sleva
    if (invoiceData.discount) {
      y += 10;
      doc.text(`Sleva 10% (pouze na položky): -${invoiceData.discountAmount.toFixed(2)} ${invoiceData.currency}`, 20, y);
    }
    
    y += 10;
    doc.text(`Položky po slevě: ${invoiceData.itemsTotal.toFixed(2)} ${invoiceData.currency}`, 20, y);
    y += 10;
    doc.text(`City Tax: ${invoiceData.cityTax.toFixed(2)} ${invoiceData.currency}`, 20, y);
    
    // Přidáme celkovou částku
    y += 15;
    doc.setFont('helvetica', 'bold');
    doc.text(`Celkem: ${invoiceData.total.toFixed(2)} ${invoiceData.currency}`, 20, y);
    doc.setFont('helvetica', 'normal');
    
    // Přidáme způsob platby
    y += 10;
    doc.text(`Způsob platby: ${invoiceData.paymentMethod}`, 20, y);
    
    // Uložíme PDF
    doc.save(`faktura_${invoiceData.villa}_${new Date().toISOString().slice(0, 10)}.pdf`);
    
    return true;
  } catch (error) {
    console.error('Chyba při exportu do PDF:', error);
    return false;
  }
}

/**
 * Exportuje historii objednávek do CSV
 * @param {Array} orders - Pole objednávek
 * @returns {boolean} True pokud byl export úspěšný
 */
export function exportOrdersToCSV(orders) {
  if (!orders || !Array.isArray(orders) || orders.length === 0) {
    console.error('Žádné objednávky k exportu');
    return false;
  }
  
  try {
    // Vytvoříme hlavičku CSV
    let csv = 'Datum,Vila,Hosté,Nocí,Měna,Způsob platby,Celková částka\n';
    
    // Přidáme řádky pro každou objednávku
    orders.forEach(order => {
      const date = new Date(order.date).toLocaleDateString();
      const villa = order.villa;
      const guests = order.guests;
      const nights = order.nights;
      const currency = order.currency;
      const paymentMethod = order.paymentMethod;
      
      // Vypočítáme celkovou částku
      let total = 0;
      order.cart.forEach(item => {
        let itemAmount = item.price * item.quantity;
        
        // Převod na cílovou měnu, pokud je to potřeba
        if (item.currency !== currency) {
          if (item.currency === 'CZK' && currency === 'EUR') {
            itemAmount = itemAmount / order.exchangeRate;
          } else if (item.currency === 'EUR' && currency === 'CZK') {
            itemAmount = itemAmount * order.exchangeRate;
          }
        }
        
        total += itemAmount;
      });
      
      // Přidáme city tax
      const cityTax = guests * nights * 2; // 2 EUR na osobu na noc
      const cityTaxInCurrency = currency === 'CZK' ? cityTax * order.exchangeRate : cityTax;
      
      total += cityTaxInCurrency;
      
      // Přidáme řádek do CSV
      csv += `${date},${villa},${guests},${nights},${currency},${paymentMethod},${total.toFixed(2)}\n`;
    });
    
    // Vytvoříme Blob a stáhneme soubor
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', `objednavky_${new Date().toISOString().slice(0, 10)}.csv`);
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    return true;
  } catch (error) {
    console.error('Chyba při exportu do CSV:', error);
    return false;
  }
}
