/**
 * Modul pro správu inventáře
 */

import { validateItem } from './utils.js';

// Konstanta pro cestu k JSON souboru s inventářem
const INVENTORY_URL = '/data/inventory.json';

// Cache pro uložení načteného inventáře
let inventoryCache = null;
let lastFetchTime = 0;
const CACHE_DURATION = 3600000; // 1 hodina v milisekundách

/**
 * Načte inventář z JSON souboru nebo z cache
 * @returns {Promise<Object>} Objekt s inventářem pro všechny vily
 */
export async function loadInventoryData() {
  const currentTime = Date.now();
  
  // Pokud máme platná data v cache, vrátíme je
  if (inventoryCache && (currentTime - lastFetchTime < CACHE_DURATION)) {
    console.log('Používám inventář z cache');
    return inventoryCache;
  }
  
  try {
    console.log('Načítám inventář z JSON souboru');
    const response = await fetch(INVENTORY_URL);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const data = await response.json();
    
    // Validace dat
    for (const villa in data) {
      data[villa] = data[villa].filter(item => validateItem(item));
    }
    
    // Aktualizace cache
    inventoryCache = data;
    lastFetchTime = currentTime;
    
    return data;
  } catch (error) {
    console.error('Chyba při načítání inventáře:', error);
    
    // V případě chyby vrátíme prázdný inventář
    return {
      'oh-yeah': [],
      'amazing-pool': [],
      'little-castle': []
    };
  }
}

/**
 * Získá inventář pro konkrétní vilu
 * @param {string} villa - Kód vily
 * @param {string} category - Kategorie položek (all, non-alcoholic, alcoholic, beer, relax)
 * @returns {Promise<Array>} Pole položek inventáře
 */
export async function getVillaInventory(villa, category = 'all') {
  const inventory = await loadInventoryData();
  
  if (!inventory[villa]) {
    console.error(`Inventář pro vilu ${villa} nebyl nalezen!`);
    return [];
  }
  
  // Filtrujeme položky podle kategorie
  return inventory[villa].filter(item => {
    return (category === 'all' || item.category === category) && item.name;
  });
}

/**
 * Resetuje cache inventáře
 */
export function resetInventoryCache() {
  inventoryCache = null;
  lastFetchTime = 0;
}
