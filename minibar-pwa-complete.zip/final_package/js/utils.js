/**
 * Utility funkce pro aplikaci správy minibaru
 */

/**
 * Formátuje cenu podle měny
 * @param {number} amount - Částka
 * @param {string} currency - Měna (CZK, EUR)
 * @returns {string} Formátovaná cena
 */
export function formatPrice(amount, currency) {
  return `${amount.toFixed(2)} ${currency}`;
}

/**
 * Validuje položku inventáře
 * @param {Object} item - Položka inventáře
 * @returns {boolean} True pokud je položka validní, jinak false
 */
export function validateItem(item) {
  if (!item.name || typeof item.price !== 'number' || !item.currency) {
    console.warn(`Neplatná položka: ${JSON.stringify(item)}`);
    return false;
  }
  return true;
}

/**
 * Převádí částku mezi měnami
 * @param {number} amount - Částka
 * @param {string} fromCurrency - Zdrojová měna
 * @param {string} toCurrency - Cílová měna
 * @param {number} exchangeRate - Směnný kurz EUR/CZK
 * @returns {number} Převedená částka
 */
export function convertCurrency(amount, fromCurrency, toCurrency, exchangeRate) {
  if (fromCurrency === toCurrency) {
    return amount;
  }
  
  if (fromCurrency === 'CZK' && toCurrency === 'EUR') {
    return amount / exchangeRate;
  } else if (fromCurrency === 'EUR' && toCurrency === 'CZK') {
    return amount * exchangeRate;
  }
  
  return amount;
}

/**
 * Získá vhodnou ikonu podle kategorie produktu
 * @param {string} category - Kategorie produktu
 * @returns {string} Třída ikony FontAwesome
 */
export function getCategoryIcon(category) {
  switch(category) {
    case 'non-alcoholic':
      return 'fa-glass-water';
    case 'alcoholic':
      return 'fa-wine-glass-alt';
    case 'beer':
      return 'fa-beer';
    case 'relax':
      return 'fa-spa';
    default:
      return 'fa-box';
  }
}

/**
 * Získá název způsobu platby
 * @param {string} method - Kód způsobu platby
 * @returns {string} Název způsobu platby
 */
export function getPaymentMethodName(method) {
  switch(method) {
    case 'cash': return 'Hotově';
    case 'card': return 'Kartou';
    case 'unpaid': return 'Neplaceno';
    default: return method;
  }
}
