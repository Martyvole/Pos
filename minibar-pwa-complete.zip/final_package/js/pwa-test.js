// Testovací skript pro PWA funkcionalitu
// Tento skript ověřuje správnou registraci Service Workeru a offline funkcionalitu

console.log('Spouštím test PWA funkcionality...');

// Funkce pro testování registrace Service Workeru
async function testServiceWorkerRegistration() {
  console.log('Test 1: Kontrola registrace Service Workeru');
  
  if (!('serviceWorker' in navigator)) {
    console.error('❌ Service Worker není podporován v tomto prohlížeči');
    return false;
  }
  
  try {
    const registration = await navigator.serviceWorker.getRegistration();
    
    if (!registration) {
      console.error('❌ Service Worker není registrován');
      return false;
    }
    
    console.log('✅ Service Worker je správně registrován');
    console.log('   Scope:', registration.scope);
    console.log('   Stav:', registration.active ? 'aktivní' : 'neaktivní');
    
    return true;
  } catch (error) {
    console.error('❌ Chyba při kontrole registrace Service Workeru:', error);
    return false;
  }
}

// Funkce pro testování cache
async function testCacheStorage() {
  console.log('Test 2: Kontrola cache storage');
  
  try {
    const cacheNames = await caches.keys();
    
    if (cacheNames.length === 0) {
      console.error('❌ Žádná cache není vytvořena');
      return false;
    }
    
    console.log('✅ Cache storage obsahuje následující cache:');
    
    for (const cacheName of cacheNames) {
      const cache = await caches.open(cacheName);
      const keys = await cache.keys();
      
      console.log(`   ${cacheName}: ${keys.length} položek`);
    }
    
    return true;
  } catch (error) {
    console.error('❌ Chyba při kontrole cache storage:', error);
    return false;
  }
}

// Funkce pro testování offline režimu
async function testOfflineMode() {
  console.log('Test 3: Simulace offline režimu');
  
  try {
    // Kontrola, zda je v cache uložena offline stránka
    const cache = await caches.open('minibar-cache-v1');
    const offlinePage = await cache.match('/offline.html');
    
    if (!offlinePage) {
      console.error('❌ Offline stránka není uložena v cache');
      return false;
    }
    
    console.log('✅ Offline stránka je správně uložena v cache');
    
    // Kontrola, zda jsou v cache uloženy důležité soubory
    const criticalAssets = [
      '/',
      '/index.html',
      '/styles.css',
      '/js/app.js',
      '/manifest.json'
    ];
    
    let allAssetsPresent = true;
    
    for (const asset of criticalAssets) {
      const response = await cache.match(asset);
      
      if (!response) {
        console.error(`❌ Důležitý soubor ${asset} není uložen v cache`);
        allAssetsPresent = false;
      }
    }
    
    if (allAssetsPresent) {
      console.log('✅ Všechny důležité soubory jsou správně uloženy v cache');
    }
    
    return allAssetsPresent;
  } catch (error) {
    console.error('❌ Chyba při testování offline režimu:', error);
    return false;
  }
}

// Funkce pro testování instalace PWA
function testInstallability() {
  console.log('Test 4: Kontrola možnosti instalace aplikace');
  
  // Kontrola, zda manifest obsahuje všechny potřebné vlastnosti
  fetch('/manifest.json')
    .then(response => response.json())
    .then(manifest => {
      let isValid = true;
      
      const requiredProperties = [
        'name',
        'short_name',
        'start_url',
        'display',
        'background_color',
        'theme_color',
        'icons'
      ];
      
      for (const prop of requiredProperties) {
        if (!manifest[prop]) {
          console.error(`❌ Manifest neobsahuje povinnou vlastnost: ${prop}`);
          isValid = false;
        }
      }
      
      if (!manifest.icons || manifest.icons.length === 0) {
        console.error('❌ Manifest neobsahuje žádné ikony');
        isValid = false;
      } else {
        // Kontrola, zda manifest obsahuje ikony potřebné pro instalaci
        const requiredSizes = ['192x192', '512x512'];
        const iconSizes = manifest.icons.map(icon => icon.sizes);
        
        for (const size of requiredSizes) {
          if (!iconSizes.includes(size)) {
            console.error(`❌ Manifest neobsahuje ikonu velikosti ${size}`);
            isValid = false;
          }
        }
      }
      
      if (isValid) {
        console.log('✅ Manifest obsahuje všechny potřebné vlastnosti pro instalaci');
        
        // Kontrola, zda jsou ikony dostupné
        Promise.all(
          manifest.icons.map(icon => 
            fetch(icon.src)
              .then(response => {
                if (!response.ok) {
                  throw new Error(`Ikona ${icon.src} není dostupná`);
                }
                return true;
              })
              .catch(error => {
                console.error(`❌ ${error.message}`);
                return false;
              })
          )
        ).then(results => {
          if (results.every(result => result)) {
            console.log('✅ Všechny ikony jsou dostupné');
          }
        });
      }
      
      return isValid;
    })
    .catch(error => {
      console.error('❌ Chyba při načítání manifestu:', error);
      return false;
    });
}

// Spuštění všech testů
async function runAllTests() {
  console.log('Spouštím všechny testy PWA funkcionality...');
  
  const swRegistered = await testServiceWorkerRegistration();
  const cacheValid = await testCacheStorage();
  const offlineModeWorks = await testOfflineMode();
  const installable = testInstallability();
  
  // Počkáme na dokončení všech testů
  setTimeout(() => {
    console.log('\nShrnutí testů:');
    console.log(`Service Worker registrace: ${swRegistered ? '✅ OK' : '❌ Selhalo'}`);
    console.log(`Cache storage: ${cacheValid ? '✅ OK' : '❌ Selhalo'}`);
    console.log(`Offline režim: ${offlineModeWorks ? '✅ OK' : '❌ Selhalo'}`);
    
    if (swRegistered && cacheValid && offlineModeWorks) {
      console.log('\n✅ PWA funkcionalita je správně implementována!');
    } else {
      console.log('\n❌ PWA funkcionalita není kompletně implementována. Zkontrolujte chyby výše.');
    }
  }, 1000);
}

// Spustíme testy po načtení stránky
window.addEventListener('load', runAllTests);
