/**
 * Modul pro správu notifikací
 */

// Výchozí nastavení notifikací
let notificationSettings = {
  duration: 2000,  // Doba zobrazení v ms
  sound: false,    // Zvukové upozornění
  icon: true       // Zobrazení ikony
};

/**
 * Zobrazí notifikaci
 * @param {string} message - Text notifikace
 * @param {Object} options - Volitelné nastavení (duration, sound, icon)
 */
export function showNotification(message, options = {}) {
  // Sloučení výchozího nastavení s předanými parametry
  const settings = { ...notificationSettings, ...options };
  
  // Kontrola, zda již existuje notifikace
  let notification = document.getElementById("cart-notification");
  
  // Pokud neexistuje, vytvoříme ji
  if (!notification) {
    notification = document.createElement("div");
    notification.id = "cart-notification";
    notification.style.position = "fixed";
    notification.style.bottom = "20px";
    notification.style.left = "50%";
    notification.style.transform = "translateX(-50%)";
    notification.style.backgroundColor = "var(--primary-color)";
    notification.style.color = "white";
    notification.style.padding = "10px 20px";
    notification.style.borderRadius = "5px";
    notification.style.boxShadow = "0 2px 8px rgba(0,0,0,0.2)";
    notification.style.zIndex = "9000";
    notification.style.fontSize = "14px";
    notification.style.fontWeight = "bold";
    notification.style.textAlign = "center";
    notification.style.opacity = "0";
    notification.style.transition = "opacity 0.3s ease";
    notification.style.display = "flex";
    notification.style.alignItems = "center";
    notification.style.gap = "10px";
    
    document.body.appendChild(notification);
  }
  
  // Přidáme ikonu úspěchu, pokud je povolena
  if (settings.icon) {
    notification.innerHTML = `<i class="fas fa-check-circle"></i> ${message}`;
  } else {
    notification.textContent = message;
  }
  
  // Přehrajeme zvuk, pokud je povolen
  if (settings.sound) {
    const audio = new Audio('/sounds/notification.mp3');
    audio.play().catch(e => console.log('Zvuk notifikace nelze přehrát:', e));
  }
  
  // Zobrazíme notifikaci s animací
  setTimeout(() => {
    notification.style.opacity = "1";
  }, 10);
  
  // Skryjeme notifikaci po uplynutí časového limitu
  setTimeout(() => {
    notification.style.opacity = "0";
  }, settings.duration);
}

/**
 * Aktualizuje nastavení notifikací
 * @param {Object} settings - Nové nastavení
 */
export function updateNotificationSettings(settings) {
  notificationSettings = { ...notificationSettings, ...settings };
  
  // Uložíme nastavení do localStorage pro perzistenci
  localStorage.setItem('notificationSettings', JSON.stringify(notificationSettings));
}

/**
 * Načte nastavení notifikací z localStorage
 */
export function loadNotificationSettings() {
  const savedSettings = localStorage.getItem('notificationSettings');
  if (savedSettings) {
    try {
      notificationSettings = { ...notificationSettings, ...JSON.parse(savedSettings) };
    } catch (e) {
      console.error('Chyba při načítání nastavení notifikací:', e);
    }
  }
  return notificationSettings;
}

// Při načtení modulu načteme uložené nastavení
loadNotificationSettings();
