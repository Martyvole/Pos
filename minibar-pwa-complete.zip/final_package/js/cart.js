/**
 * Modul pro správu košíku
 */

import { formatPrice, convertCurrency } from './utils.js';

// Košík a související proměnné
let cart = [];
let selectedItem = null;
let selectedQuantity = 1;

/**
 * Přidá položku do košíku
 * @param {Object} item - Položka k přidání
 * @param {number} quantity - Množství
 * @returns {boolean} True pokud byla položka úspěšně přidána
 */
export function addToCart(item, quantity) {
  if (!item) return false;
  
  // Pro položky s vlastní cenou zobrazíme dialog pro zadání ceny
  if (item.customPrice) {
    const customPrice = prompt("Zadejte cenu:", "0");
    if (customPrice === null) {
      return false;
    }
    
    const parsedPrice = parseFloat(customPrice);
    if (isNaN(parsedPrice) || parsedPrice < 0) {
      alert("Prosím zadejte platnou cenu.");
      return false;
    }
    
    item = { 
      ...item,
      price: parsedPrice
    };
  }
  
  // Kontrola, zda již položka v košíku existuje
  const existingItemIndex = cart.findIndex(cartItem => 
    cartItem.name === item.name && 
    cartItem.price === item.price &&
    cartItem.currency === item.currency
  );
  
  if (existingItemIndex !== -1) {
    // Položka již existuje, navýšíme množství
    cart[existingItemIndex].quantity += quantity;
  } else {
    // Přidáme novou položku do košíku
    cart.push({
      ...item,
      quantity: quantity
    });
  }
  
  return true;
}

/**
 * Odstraní položku z košíku
 * @param {number} index - Index položky v košíku
 * @returns {boolean} True pokud byla položka úspěšně odstraněna
 */
export function removeFromCart(index) {
  if (index < 0 || index >= cart.length) return false;
  
  if (confirm("Opravdu chcete odstranit tuto položku z košíku?")) {
    cart.splice(index, 1);
    return true;
  }
  
  return false;
}

/**
 * Vyprázdní košík
 * @returns {boolean} True pokud byl košík úspěšně vyprázdněn
 */
export function clearCart() {
  if (cart.length === 0) return false;
  
  if (confirm("Přejete si vyprázdnit košík?")) {
    cart = [];
    return true;
  }
  
  return false;
}

/**
 * Získá obsah košíku
 * @returns {Array} Pole položek v košíku
 */
export function getCart() {
  return [...cart];
}

/**
 * Nastaví vybranou položku a množství
 * @param {Object} item - Vybraná položka
 * @param {number} quantity - Množství
 */
export function setSelectedItem(item, quantity = 1) {
  selectedItem = item;
  selectedQuantity = quantity;
}

/**
 * Získá vybranou položku
 * @returns {Object} Vybraná položka
 */
export function getSelectedItem() {
  return selectedItem;
}

/**
 * Získá vybrané množství
 * @returns {number} Vybrané množství
 */
export function getSelectedQuantity() {
  return selectedQuantity;
}

/**
 * Nastaví vybrané množství
 * @param {number} quantity - Množství
 */
export function setSelectedQuantity(quantity) {
  selectedQuantity = quantity;
}

/**
 * Vypočítá celkovou částku v košíku
 * @param {string} targetCurrency - Cílová měna (CZK, EUR)
 * @param {number} exchangeRate - Směnný kurz EUR/CZK
 * @returns {number} Celková částka
 */
export function calculateTotalAmount(targetCurrency, exchangeRate) {
  return cart.reduce((total, item) => {
    let itemAmount = item.price * item.quantity;
    
    // Převod na cílovou měnu
    if (item.currency !== targetCurrency) {
      itemAmount = convertCurrency(itemAmount, item.currency, targetCurrency, exchangeRate);
    }
    
    return total + itemAmount;
  }, 0);
}

/**
 * Získá počet položek v košíku
 * @returns {number} Počet položek
 */
export function getCartItemCount() {
  return cart.reduce((total, item) => total + item.quantity, 0);
}
