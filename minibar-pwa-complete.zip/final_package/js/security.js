/**
 * Modul pro sanitizaci vstupů a ochranu proti XSS útokům
 */

/**
 * Sanitizuje HTML řetězec
 * @param {string} html - HTML řetězec k sanitizaci
 * @param {Object} options - Volitelné nastavení
 * @returns {string} Sanitizovaný HTML řetězec
 */
export function sanitizeHtml(html, options = {}) {
  if (!html) return '';
  
  // Výchozí nastavení
  const defaultOptions = {
    allowedTags: ['div', 'span', 'h2', 'h3', 'p', 'strong', 'em', 'b', 'i', 'br'],
    allowedAttributes: {}
  };
  
  // Sloučení výchozího nastavení s předanými parametry
  const settings = { ...defaultOptions, ...options };
  
  // Vytvoříme dočasný element pro sanitizaci
  const tempElement = document.createElement('div');
  tempElement.innerHTML = html;
  
  // Rekurzivní funkce pro sanitizaci elementů
  function sanitizeElement(element) {
    // Získáme všechny potomky
    const childNodes = Array.from(element.childNodes);
    
    for (const node of childNodes) {
      if (node.nodeType === Node.ELEMENT_NODE) {
        const tagName = node.tagName.toLowerCase();
        
        // Kontrola, zda je tag povolený
        if (!settings.allowedTags.includes(tagName)) {
          // Pokud tag není povolený, nahradíme ho jeho obsahem
          const fragment = document.createDocumentFragment();
          while (node.firstChild) {
            fragment.appendChild(node.firstChild);
          }
          node.parentNode.replaceChild(fragment, node);
        } else {
          // Kontrola atributů
          const attributes = Array.from(node.attributes);
          for (const attr of attributes) {
            const attrName = attr.name;
            
            // Kontrola, zda je atribut povolený pro tento tag
            const allowedAttrsForTag = settings.allowedAttributes[tagName] || [];
            if (!allowedAttrsForTag.includes(attrName)) {
              node.removeAttribute(attrName);
            }
          }
          
          // Rekurzivně sanitizujeme potomky
          sanitizeElement(node);
        }
      }
    }
  }
  
  // Spustíme sanitizaci
  sanitizeElement(tempElement);
  
  // Vrátíme sanitizovaný HTML
  return tempElement.innerHTML;
}

/**
 * Escapuje HTML znaky v řetězci
 * @param {string} text - Řetězec k escapování
 * @returns {string} Escapovaný řetězec
 */
export function escapeHtml(text) {
  if (!text) return '';
  
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  
  return text.replace(/[&<>"']/g, m => map[m]);
}

/**
 * Sanitizuje vstupní hodnotu
 * @param {string} value - Hodnota k sanitizaci
 * @returns {string} Sanitizovaná hodnota
 */
export function sanitizeInput(value) {
  if (!value) return '';
  
  // Odstraníme nebezpečné znaky
  return value.replace(/[<>]/g, '');
}

/**
 * Sanitizuje objekt s daty
 * @param {Object} data - Objekt k sanitizaci
 * @returns {Object} Sanitizovaný objekt
 */
export function sanitizeObject(data) {
  if (!data || typeof data !== 'object') return {};
  
  const result = {};
  
  for (const key in data) {
    if (Object.prototype.hasOwnProperty.call(data, key)) {
      const value = data[key];
      
      if (typeof value === 'string') {
        result[key] = sanitizeInput(value);
      } else if (Array.isArray(value)) {
        result[key] = value.map(item => 
          typeof item === 'string' ? sanitizeInput(item) : 
          typeof item === 'object' ? sanitizeObject(item) : 
          item
        );
      } else if (typeof value === 'object' && value !== null) {
        result[key] = sanitizeObject(value);
      } else {
        result[key] = value;
      }
    }
  }
  
  return result;
}
