# Návod k nasazení PWA aplikace Správa Minibaru

Tento dokument obsahuje instrukce pro nasazení Progressive Web Application (PWA) verze aplikace Správa Minibaru.

## Obsah balíčku

Archiv `minibar-pwa.zip` obsahuje optimalizovanou verzi aplikace s následujícími soubory:

- Minifikované JS a CSS soubory v adresáři `dist/`
- PWA manifest (`manifest.json`)
- Service Worker pro offline funkcionalitu (`service-worker.js`)
- Offline stránka (`offline.html`)
- PWA ikony (`icon-192.png` a `icon-512.png`)
- Všechny potřebné obrázky produktů

## Požadavky pro nasazení

- Webový server s podporou HTTPS (nutné pro PWA funkcionalitu)
- Podpora pro JavaScript a moderní webové prohlížeče

## Postup nasazení

1. Rozbalte archiv `minibar-pwa.zip` do kořenového adresáře vašeho webového serveru
2. Ujistěte se, že všechny soubory jsou přístupné přes HTTPS
3. Otestujte aplikaci navigací na hlavní stránku (index.html)

## Testování PWA funkcionality

Pro ověření správné funkčnosti PWA:

1. Otevřete aplikaci v prohlížeči Chrome nebo jiném moderním prohlížeči
2. Otevřete vývojářské nástroje (F12) a přejděte na záložku "Application"
3. Zkontrolujte, zda je Service Worker správně registrován
4. Ověřte, že manifest je správně načten
5. Zkuste aplikaci používat v offline režimu (můžete použít "Offline" přepínač ve vývojářských nástrojích)
6. Zkuste aplikaci nainstalovat kliknutím na ikonu instalace v adresním řádku

Můžete také použít testovací stránku `pwa-test.html`, která obsahuje automatické testy PWA funkcionality.

## Struktura aplikace

Aplikace je rozdělena do následujících modulů:

- `app.js` - Hlavní aplikační logika
- `inventory.js` - Správa inventáře
- `cart.js` - Logika košíku
- `utils.js` - Pomocné funkce
- `notifications.js` - Systém notifikací
- `history.js` - Správa historie objednávek
- `exchange.js` - Aktualizace směnných kurzů
- `i18n.js` - Vícejazyčná podpora
- `security.js` - Bezpečnostní funkce
- `barcode.js` - Skenování čárových kódů
- `export.js` - Export dat do PDF a CSV

## Konfigurace

Data inventáře jsou uložena v souboru `data/inventory.json`. Tento soubor můžete upravit pro přidání, odebrání nebo změnu položek v inventáři.

## Offline funkcionalita

Aplikace funguje i bez připojení k internetu díky Service Workeru, který ukládá potřebné soubory do cache. Při prvním načtení aplikace se stáhnou všechny potřebné soubory, které jsou pak dostupné i offline.

## Aktualizace aplikace

Pro aktualizaci aplikace:

1. Upravte zdrojové soubory
2. Spusťte skript `minify.sh` pro vytvoření nové optimalizované verze
3. Nahraďte soubory na serveru

Service Worker automaticky detekuje změny a aktualizuje cache při příštím načtení aplikace.

## Podpora prohlížečů

Aplikace je optimalizována pro moderní prohlížeče:
- Chrome (verze 70+)
- Firefox (verze 63+)
- Safari (verze 11.1+)
- Edge (verze 79+)

PWA funkcionalita může být omezena v některých starších prohlížečích.

## Řešení problémů

Pokud se vyskytnou problémy s PWA funkcionalitou:

1. Ujistěte se, že server používá HTTPS
2. Zkontrolujte, zda jsou všechny soubory správně nahrány
3. Vyčistěte cache prohlížeče a zkuste aplikaci znovu načíst
4. Zkontrolujte konzoli prohlížeče pro případné chybové zprávy

Pro další pomoc kontaktujte podporu.
