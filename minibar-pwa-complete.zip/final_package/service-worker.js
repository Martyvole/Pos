// Service Worker pro PWA aplikaci Správa Minibaru
const CACHE_NAME = 'minibar-cache-v1';
const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  '/styles.css',
  '/js/app.js',
  '/js/utils.js',
  '/js/inventory.js',
  '/js/cart.js',
  '/js/notifications.js',
  '/js/history.js',
  '/js/exchange.js',
  '/js/i18n.js',
  '/js/security.js',
  '/js/barcode.js',
  '/js/export.js',
  '/data/inventory.json',
  '/manifest.json',
  '/icon-192.png',
  '/icon-512.png',
  '/sounds/notification.mp3',
  // Obrázky produktů
  '/30keg.png',
  '/50keg.png',
  '/budvar.png',
  '/cola.png',
  '/fanta.png',
  '/gin.png',
  '/grill.png',
  '/jack.png',
  '/malibu.png',
  '/mojito.png',
  '/moscow.png',
  '/sprite.png',
  '/pivo50.png',
  '/keg.png',
  '/prosecco.png',
  '/redbull.png',
  '/wellness.png',
  // Externí zdroje
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
  'https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap',
  'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js',
  'https://cdn.jsdelivr.net/npm/quagga@0.12.1/dist/quagga.min.js'
];

// Instalace Service Workeru
self.addEventListener('install', (event) => {
  console.log('Service Worker: Instalace');
  
  // Předběžné načtení a uložení souborů do cache
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Service Worker: Otevírám cache');
        return cache.addAll(ASSETS_TO_CACHE);
      })
      .then(() => {
        console.log('Service Worker: Všechny soubory byly uloženy do cache');
        return self.skipWaiting();
      })
      .catch((error) => {
        console.error('Service Worker: Chyba při ukládání do cache:', error);
      })
  );
});

// Aktivace Service Workeru
self.addEventListener('activate', (event) => {
  console.log('Service Worker: Aktivace');
  
  // Odstranění starých verzí cache
  event.waitUntil(
    caches.keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => {
            if (cacheName !== CACHE_NAME) {
              console.log('Service Worker: Odstraňuji starou cache', cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      })
      .then(() => {
        console.log('Service Worker: Nyní je aktivní');
        return self.clients.claim();
      })
  );
});

// Zachycení požadavků na síť
self.addEventListener('fetch', (event) => {
  // Strategie Cache First, pak Network
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        // Vrátíme soubor z cache, pokud existuje
        if (response) {
          console.log('Service Worker: Vracím z cache', event.request.url);
          return response;
        }
        
        console.log('Service Worker: Stahuji ze sítě', event.request.url);
        
        // Jinak stáhneme ze sítě
        return fetch(event.request)
          .then((networkResponse) => {
            // Pokud je odpověď neplatná, vrátíme ji přímo
            if (!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
              return networkResponse;
            }
            
            // Jinak uložíme kopii do cache pro příští použití
            const responseToCache = networkResponse.clone();
            
            caches.open(CACHE_NAME)
              .then((cache) => {
                cache.put(event.request, responseToCache);
                console.log('Service Worker: Ukládám do cache', event.request.url);
              });
            
            return networkResponse;
          })
          .catch((error) => {
            console.error('Service Worker: Chyba při stahování ze sítě:', error);
            
            // Pokud jde o požadavek na HTML stránku a jsme offline, vrátíme offline stránku
            if (event.request.headers.get('accept').includes('text/html')) {
              return caches.match('/offline.html');
            }
          });
      })
  );
});

// Synchronizace dat při obnovení připojení
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-orders') {
    console.log('Service Worker: Synchronizuji objednávky');
    event.waitUntil(syncOrders());
  }
});

// Funkce pro synchronizaci objednávek
async function syncOrders() {
  try {
    // Získáme všechny neuložené objednávky z IndexedDB
    const pendingOrders = await getPendingOrders();
    
    if (pendingOrders.length === 0) {
      console.log('Service Worker: Žádné objednávky k synchronizaci');
      return;
    }
    
    console.log('Service Worker: Synchronizuji', pendingOrders.length, 'objednávek');
    
    // Zde by byla logika pro odeslání objednávek na server
    // Pro demonstraci pouze označíme objednávky jako synchronizované
    await markOrdersAsSynced(pendingOrders);
    
    console.log('Service Worker: Synchronizace dokončena');
    
    // Informujeme všechny otevřené klienty o dokončení synchronizace
    const clients = await self.clients.matchAll();
    clients.forEach(client => {
      client.postMessage({
        type: 'sync-complete',
        orders: pendingOrders.length
      });
    });
  } catch (error) {
    console.error('Service Worker: Chyba při synchronizaci:', error);
  }
}

// Pomocné funkce pro práci s IndexedDB (implementace by byla v reálné aplikaci)
async function getPendingOrders() {
  // Simulace získání neuložených objednávek
  return [];
}

async function markOrdersAsSynced(orders) {
  // Simulace označení objednávek jako synchronizovaných
  return true;
}

// Zpracování push notifikací
self.addEventListener('push', (event) => {
  console.log('Service Worker: Přijata push notifikace');
  
  const data = event.data.json();
  
  const options = {
    body: data.body,
    icon: '/icon-192.png',
    badge: '/icon-192.png',
    vibrate: [100, 50, 100],
    data: {
      url: data.url || '/'
    }
  };
  
  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

// Akce po kliknutí na notifikaci
self.addEventListener('notificationclick', (event) => {
  console.log('Service Worker: Kliknuto na notifikaci');
  
  event.notification.close();
  
  event.waitUntil(
    clients.openWindow(event.notification.data.url)
  );
});
