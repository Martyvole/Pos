// Globální proměnné aplikace
let selectedVilla = "oh-yeah"; // Výchozí vila
let cart = [];
let selectedItem = null;
let selectedQuantity = 1;
let exchangeRate = 24.5; // Výchozí kurz EUR/CZK
const CITY_TAX_PER_PERSON_PER_NIGHT = 2; // 2 EUR na osobu na noc

// Po načtení stránky inicializujeme aplikaci
document.addEventListener("DOMContentLoaded", function() {
    // Nastavíme event listenery pro vily
    setupVillaListeners();
    
    // Zvýrazníme vybranou vilu
    highlightSelectedVilla();
    
    // Načteme položky inventáře pro výchozí vilu
    loadInventory();
    
    // Nastavíme event listenery pro kategorie
    setupCategoryListeners();
    
    // Nastavíme event listenery pro počet hostů a nocí
    setupGuestsAndNightsListeners();
    
    // Aktualizujeme statistiky v přehledu
    updateStats();
});

// Nastavení posluchačů událostí pro počet hostů a nocí
function setupGuestsAndNightsListeners() {
    const guestsInput = document.getElementById('guests');
    const nightsInput = document.getElementById('nights');
    
    if (guestsInput) {
        guestsInput.addEventListener('change', function() {
            updateStats();
        });
    }
    
    if (nightsInput) {
        nightsInput.addEventListener('change', function() {
            updateStats();
        });
    }
}

// Nastavení posluchačů událostí pro tlačítka vil
function setupVillaListeners() {
    document.querySelectorAll(".villa-btn").forEach(btn => {
        btn.addEventListener("click", function() {
            const villa = this.classList.contains("oh-yeah") ? "oh-yeah" 
                        : this.classList.contains("amazing-pool") ? "amazing-pool"
                        : "little-castle";
            
            selectVilla(villa);
        });
    });
}

// Funkce pro výběr vily
function selectVilla(villa) {
    selectedVilla = villa;
    highlightSelectedVilla();
    loadInventory();
}

// Zvýraznění vybrané vily
function highlightSelectedVilla() {
    // Odebereme třídu "active" ze všech tlačítek vil
    document.querySelectorAll(".villa-btn").forEach(btn => {
        btn.classList.remove("active");
    });
    
    // Přidáme třídu "active" vybranému tlačítku
    const selectedBtn = document.querySelector(`.villa-btn.${selectedVilla}`);
    if (selectedBtn) {
        selectedBtn.classList.add("active");
    }
}

// Nastavení event listenerů pro kategorie
function setupCategoryListeners() {
    document.querySelectorAll('.category-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            // Odebereme třídu active ze všech tabů
            document.querySelectorAll('.category-tab').forEach(t => {
                t.classList.remove('active');
            });
            
            // Přidáme třídu active kliknutému tabu
            this.classList.add('active');
            
            // Načteme položky pro vybranou kategorii
            loadInventory();
        });
    });

    // Nastavení poslouchače události pro input množství
    const quantityInput = document.getElementById('quantityInput');
    if (quantityInput) {
        quantityInput.addEventListener('change', function() {
            // Zajistíme, že hodnota je minimálně 1 (pokud není prázdná)
            if (this.value && parseInt(this.value) < 1) {
                this.value = 1;
            }
            selectedQuantity = parseInt(this.value) || 1;
        });
    }
}

// Načtení položek inventáře podle vybrané vily a aktuální kategorie
function loadInventory() {
    const inventoryContainer = document.getElementById("inventory");
    if (!inventoryContainer) {
        console.error("Element #inventory nebyl nalezen");
        return;
    }
    
    inventoryContainer.innerHTML = "";
    
    // Získáme aktuální kategorii
    const activeTab = document.querySelector(".category-tab.active");
    if (!activeTab) {
        console.error("Žádná aktivní kategorie nebyla nalezena");
        return;
    }
    
    const activeCategory = activeTab.dataset.category;
    
    // Kontrola, zda existuje inventář a vybraná vila
    if (!inventory) {
        console.error("Proměnná 'inventory' není definována. Ujistěte se, že je soubor inventory.js načten před app.js.");
        return;
    }
    
    // Filtrujeme položky podle kategorie
    const villaInventory = inventory[selectedVilla];
    
    // Kontrola, zda inventář existuje
    if (!villaInventory) {
        console.error(`Inventář pro vilu ${selectedVilla} nebyl nalezen!`);
        return;
    }
    
    const filteredItems = villaInventory.filter(item => {
        return (activeCategory === "all" || item.category === activeCategory) && item.name;
    });
    
    // Přidáme položky do kontejneru
    filteredItems.forEach(item => {
        const itemElement = createItemElement(item);
        inventoryContainer.appendChild(itemElement);
    });
}

// Vytvoření HTML elementu pro položku inventáře
function createItemElement(item) {
    const itemElement = document.createElement("div");
    itemElement.className = `item ${selectedVilla}`;
    
    // Přidáme obrázek nebo ikonu
    if (item.image) {
        // Nejprve zkontrolujeme, zda existuje obrázek
        const img = document.createElement("img");
        img.src = item.image;
        img.className = "item-image";
        img.alt = item.name;
        img.onerror = function() {
            // Pokud obrázek neexistuje, nahradíme ho ikonou
            this.onerror = null;
            this.remove();
            const icon = document.createElement("i");
            icon.className = `item-icon fas ${getCategoryIcon(item.category)}`;
            itemElement.insertBefore(icon, itemElement.firstChild);
        };
        itemElement.appendChild(img);
    } else {
        const icon = document.createElement("i");
        icon.className = `item-icon fas ${getCategoryIcon(item.category)}`;
        itemElement.appendChild(icon);
    }
    
    // Název položky
    const nameElement = document.createElement("div");
    nameElement.className = "item-name";
    nameElement.textContent = item.name;
    itemElement.appendChild(nameElement);
    
    // Cena položky
    const priceElement = document.createElement("div");
    priceElement.className = "item-price";
    
    // Formátování ceny podle měny
    const formattedPrice = item.customPrice 
        ? "Vlastní cena"
        : `${item.price} ${item.currency}`;
    
    priceElement.textContent = formattedPrice;
    itemElement.appendChild(priceElement);
    
    // Event listener pro kliknutí na položku
    itemElement.addEventListener("click", function() {
        selectItem(item);
    });
    
    return itemElement;
}

// Získání vhodné ikony podle kategorie produktu
function getCategoryIcon(category) {
    switch(category) {
        case 'non-alcoholic':
            return 'fa-glass-water';
        case 'alcoholic':
            return 'fa-wine-glass-alt';
        case 'beer':
            return 'fa-beer';
        case 'relax':
            return 'fa-spa';
        default:
            return 'fa-box';
    }
}

// Funkce pro výběr položky
function selectItem(item) {
    selectedItem = item;
    selectedQuantity = 1;
    
    // Zobrazení a nastavení selektoru množství
    const selectedItemNameEl = document.getElementById("selectedItemName");
    const selectedItemPriceEl = document.getElementById("selectedItemPrice");
    if (selectedItemNameEl) selectedItemNameEl.textContent = item.name;
    if (selectedItemPriceEl) {
        selectedItemPriceEl.textContent = item.customPrice 
            ? "Vlastní cena"
            : `${item.price} ${item.currency}`;
    }
    
    // Resetujeme input pro množství - nastavíme na prázdné pole
    const quantityInput = document.getElementById('quantityInput');
    if (quantityInput) {
        quantityInput.value = "";
        quantityInput.placeholder = "Zadejte množství";
        quantityInput.focus(); // Automaticky zaměříme na pole pro množství
    }
    
    // Zobrazení selektoru množství
    const quantitySelector = document.getElementById("quantitySelector");
    if (quantitySelector) {
        quantitySelector.style.display = "flex";
    }
}

// Skrytí selektoru množství
function hideQuantitySelector() {
    const quantitySelector = document.getElementById("quantitySelector");
    if (quantitySelector) {
        quantitySelector.style.display = "none";
    }
}

// Funkce potvrzení množství a přidání do košíku
function confirmQuantity() {
    if (!selectedItem) return;
    
    // Získáme množství z inputu
    const quantityInput = document.getElementById('quantityInput');
    if (quantityInput) {
        selectedQuantity = parseInt(quantityInput.value) || 1;
    }
    
    // Pro položky s vlastní cenou zobrazíme dialog pro zadání ceny
    if (selectedItem.customPrice) {
        const customPrice = prompt("Zadejte cenu:", "0");
        if (customPrice === null) {
            hideQuantitySelector();
            return;
        }
        
        const parsedPrice = parseFloat(customPrice);
        if (isNaN(parsedPrice) || parsedPrice < 0) {
            alert("Prosím zadejte platnou cenu.");
            return;
        }
        
        selectedItem = { 
            ...selectedItem,
            price: parsedPrice
        };
    }
    
    // Kontrola, zda již položka v košíku existuje
    const existingItemIndex = cart.findIndex(item => 
        item.name === selectedItem.name && 
        item.price === selectedItem.price &&
        item.currency === selectedItem.currency
    );
    
    if (existingItemIndex !== -1) {
        // Položka již existuje, navýšíme množství
        cart[existingItemIndex].quantity += selectedQuantity;
    } else {
        // Přidáme novou položku do košíku
        cart.push({
            ...selectedItem,
            quantity: selectedQuantity
        });
    }
    
    // Skryjeme selektor množství
    hideQuantitySelector();
    
    // Aktualizujeme statistiky
    updateStats();
    
    // Zobrazíme notifikaci o přidání do košíku místo otevření košíku
    const itemName = selectedItem.name;
    const message = `${itemName} (${selectedQuantity}x) přidáno do košíku`;
    
    // Vytvoříme dočasnou notifikaci
    showNotification(message);
}

// Funkce pro zobrazení notifikace
function showNotification(message, duration = 2000) {
    // Kontrola, zda již existuje notifikace
    let notification = document.getElementById("cart-notification");
    
    // Pokud neexistuje, vytvoříme ji
    if (!notification) {
        notification = document.createElement("div");
        notification.id = "cart-notification";
        notification.style.position = "fixed";
        notification.style.bottom = "20px";
        notification.style.left = "50%";
        notification.style.transform = "translateX(-50%)";
        notification.style.backgroundColor = "var(--primary-color)";
        notification.style.color = "white";
        notification.style.padding = "10px 20px";
        notification.style.borderRadius = "5px";
        notification.style.boxShadow = "0 2px 8px rgba(0,0,0,0.2)";
        notification.style.zIndex = "9000";
        notification.style.fontSize = "14px";
        notification.style.fontWeight = "bold";
        notification.style.textAlign = "center";
        notification.style.opacity = "0";
        notification.style.transition = "opacity 0.3s ease";
        
        document.body.appendChild(notification);
    }
    
    // Aktualizujeme text a zobrazíme notifikaci
    notification.textContent = message;
    
    // Zobrazíme notifikaci s animací
    setTimeout(() => {
        notification.style.opacity = "1";
    }, 10);
    
    // Skryjeme notifikaci po uplynutí časového limitu
    setTimeout(() => {
        notification.style.opacity = "0";
    }, duration);
}

// Výpočet city tax (2 EUR na osobu na noc)
function calculateCityTax() {
    const guestsEl = document.getElementById("guests");
    const nightsEl = document.getElementById("nights");
    
    if (!guestsEl || !nightsEl) return 0;
    
    const guests = parseInt(guestsEl.value) || 1;
    const nights = parseInt(nightsEl.value) || 1;
    
    return guests * nights * CITY_TAX_PER_PERSON_PER_NIGHT;
}

// Aktualizace statistik
function updateStats() {
    // Počet položek v košíku
    const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
    const totalItemsEl = document.getElementById("totalItems");
    const cartCountEl = document.getElementById("cartCount");
    
    if (totalItemsEl) totalItemsEl.textContent = totalItems;
    if (cartCountEl) cartCountEl.textContent = totalItems;
    
    // Celková částka
    const currencyEl = document.getElementById("currency");
    if (!currencyEl) return;
    
    const currency = currencyEl.value;
    const itemsTotal = calculateTotalAmount(currency);
    
    // Zjistíme, zda je aktivní sleva
    const discountEl = document.getElementById("discount");
    const discount = discountEl ? discountEl.checked : false;
    
    // Výpočet city tax v aktuální měně
    let cityTax = calculateCityTax();
    if (currency === 'CZK') {
        cityTax = cityTax * exchangeRate;
    }
    
    // Aplikujeme slevu pouze na položky z minibaru, ne na city tax
    let finalItemsAmount = discount ? itemsTotal * 0.9 : itemsTotal;
    
    // Celková částka = položky + city tax
    const finalTotal = finalItemsAmount + cityTax;
    
    const totalAmountEl = document.getElementById("totalAmount");
    if (totalAmountEl) {
        totalAmountEl.textContent = `${finalTotal.toFixed(2)} ${currency}`;
    }
    
    // Aktualizujeme také celkovou částku v košíku
    updateCartTotal(cityTax);
}

// Výpočet celkové částky v požadované měně
function calculateTotalAmount(targetCurrency) {
    return cart.reduce((total, item) => {
        let itemAmount = item.price * item.quantity;
        
        // Převod na cílovou měnu
        if (item.currency !== targetCurrency) {
            if (item.currency === 'CZK' && targetCurrency === 'EUR') {
                itemAmount = itemAmount / exchangeRate;
            } else if (item.currency === 'EUR' && targetCurrency === 'CZK') {
                itemAmount = itemAmount * exchangeRate;
            }
        }
        
        return total + itemAmount;
    }, 0);
}

// Přepínání zobrazení košíku
function toggleCart(forceShow = false) {
    const cartPanel = document.getElementById("cartPanel");
    if (!cartPanel) return;
    
    if (forceShow) {
        cartPanel.classList.add("active");
    } else {
        cartPanel.classList.toggle("active");
    }
    
    if (cartPanel.classList.contains("active")) {
        renderCartItems();
        document.body.style.overflow = 'hidden'; // Zamezí scrollování na pozadí
    } else {
        document.body.style.overflow = ''; // Obnoví scrollování
    }
}

// Vykreslení položek v košíku
function renderCartItems() {
    const cartItemsContainer = document.getElementById("cartItems");
    if (!cartItemsContainer) return;
    
    cartItemsContainer.innerHTML = "";
    
    if (cart.length === 0) {
        cartItemsContainer.innerHTML = "<p style='text-align: center; padding: 20px;'>Košík je prázdný</p>";
        
        // Aktualizujeme celkovou částku
        updateCartTotal();
        return;
    }
    
    // Vytvoříme položky košíku
    cart.forEach((item, index) => {
        const cartItem = document.createElement("div");
        cartItem.className = "cart-item";
        
        const itemInfo = document.createElement("div");
        itemInfo.style.display = "flex";
        itemInfo.style.alignItems = "center";
        
        const quantityBadge = document.createElement("span");
        quantityBadge.className = "cart-item-quantity";
        quantityBadge.textContent = item.quantity + "x";
        itemInfo.appendChild(quantityBadge);
        
        const itemName = document.createElement("span");
        itemName.textContent = item.name;
        itemInfo.appendChild(itemName);
        
        cartItem.appendChild(itemInfo);
        
        const itemActions = document.createElement("div");
        itemActions.style.display = "flex";
        itemActions.style.alignItems = "center";
        itemActions.style.gap = "10px";
        
        const itemPrice = document.createElement("span");
        itemPrice.textContent = `${(item.price * item.quantity).toFixed(2)} ${item.currency}`;
        itemActions.appendChild(itemPrice);
        
        const removeButton = document.createElement("button");
        removeButton.className = "cart-item-remove";
        removeButton.innerHTML = '<i class="fas fa-trash"></i>';
        removeButton.addEventListener("click", (e) => {
            e.stopPropagation(); // Zabraňuje bubblování události
            removeCartItem(index);
        });
        itemActions.appendChild(removeButton);
        
        cartItem.appendChild(itemActions);
        
        cartItemsContainer.appendChild(cartItem);
    });
    
    // Přidání položky city tax
    addCityTaxToCart(cartItemsContainer);
    
    // Aktualizujeme celkovou částku
    updateCartTotal();
}

// Přidání položky city tax do košíku
function addCityTaxToCart(container) {
    // Získáme počet hostů a nocí
    const guestsEl = document.getElementById("guests");
    const nightsEl = document.getElementById("nights");
    const currencyEl = document.getElementById("currency");
    
    if (!guestsEl || !nightsEl || !currencyEl) return;
    
    const guests = parseInt(guestsEl.value) || 1;
    const nights = parseInt(nightsEl.value) || 1;
    const currency = currencyEl.value;
    
    // Výpočet city tax
    let cityTaxAmount = guests * nights * CITY_TAX_PER_PERSON_PER_NIGHT;
    let taxCurrency = 'EUR';
    
    // Převod na aktuální měnu
    if (currency === 'CZK') {
        cityTaxAmount = cityTaxAmount * exchangeRate;
        taxCurrency = 'CZK';
    }
    
    // Vytvoření položky city tax
    const taxItem = document.createElement("div");
    taxItem.className = "cart-item city-tax";
    taxItem.style.background = "#f0f0f0";
    taxItem.style.fontStyle = "italic";
    
    const taxInfo = document.createElement("div");
    
    const taxLabel = document.createElement("span");
    taxLabel.textContent = `City Tax (${guests} ${guests > 1 ? 'osob' : 'osoba'} × ${nights} ${nights > 1 ? 'nocí' : 'noc'} × 2 EUR)`;
    taxInfo.appendChild(taxLabel);
    
    taxItem.appendChild(taxInfo);
    
    const taxPrice = document.createElement("div");
    taxPrice.textContent = `${cityTaxAmount.toFixed(2)} ${taxCurrency}`;
    
    taxItem.appendChild(taxPrice);
    
    container.appendChild(taxItem);
}

// Aktualizace celkové částky v košíku
function updateCartTotal(cityTax) {
    const cartTotalElement = document.getElementById("cartTotal");
    if (!cartTotalElement) return;
    
    const currencyEl = document.getElementById("currency");
    if (!currencyEl) return;
    
    const currency = currencyEl.value;
    const itemsTotal = calculateTotalAmount(currency);
    
    const discountEl = document.getElementById("discount");
    const discount = discountEl ? discountEl.checked : false;
    
    // Pokud city tax není zadáno, vypočítáme ji
    if (cityTax === undefined) {
        cityTax = calculateCityTax();
        if (currency === 'CZK') {
            cityTax = cityTax * exchangeRate;
        }
    }
    
    // Aplikujeme slevu pouze na položky, ne na city tax
    const finalItemsAmount = discount ? itemsTotal * 0.9 : itemsTotal;
    const finalTotal = finalItemsAmount + cityTax;
    
    // Aktualizujeme zobrazení v košíku
    cartTotalElement.textContent = `${finalTotal.toFixed(2)} ${currency}`;
}

// Odstranění položky z košíku
function removeCartItem(index) {
    if (confirm("Opravdu chcete odstranit tuto položku z košíku?")) {
        cart.splice(index, 1);
        renderCartItems();
        updateStats();
    }
}

// Generování faktury
function generateInvoice() {
    if (cart.length === 0) {
        alert("Košík je prázdný. Přidejte prosím položky do košíku.");
        return;
    }

    const invoiceModal = document.getElementById("invoiceModal");
    const invoiceContent = document.getElementById("invoiceContent");
    if (!invoiceModal || !invoiceContent) return;
    
    // Základní informace
    const currencyEl = document.getElementById("currency");
    const guestsEl = document.getElementById("guests");
    const nightsEl = document.getElementById("nights");
    const paymentMethodEl = document.getElementById("paymentMethod");
    const discountEl = document.getElementById("discount");
    
    if (!currencyEl || !guestsEl || !nightsEl || !paymentMethodEl) return;
    
    const currency = currencyEl.value;
    const guests = guestsEl.value;
    const nights = nightsEl.value;
    const paymentMethod = paymentMethodEl.value;
    const discount = discountEl ? discountEl.checked : false;
    
    // Celková částka položek
    const itemsSubtotal = calculateTotalAmount(currency);
    
    // City tax
    let cityTax = guests * nights * CITY_TAX_PER_PERSON_PER_NIGHT;
    if (currency === 'CZK') {
        cityTax = cityTax * exchangeRate;
    }
    
    // Sleva (pouze na položky, ne na city tax)
    const itemsDiscount = discount ? itemsSubtotal * 0.1 : 0;
    const itemsTotal = itemsSubtotal - itemsDiscount;
    
    // Celková částka včetně city tax
    const finalTotal = itemsTotal + cityTax;
    
    // Vytvoření obsahu faktury
    let invoiceHTML = `
        <div class="invoice-header">
            <h2>${selectedVilla.charAt(0).toUpperCase() + selectedVilla.slice(1).replace('-', ' ')} Villa</h2>
            <p>Datum: ${new Date().toLocaleDateString()}</p>
            <p>Hosté: ${guests} | Nocí: ${nights}</p>
        </div>
        <div class="invoice-items">
            <h3>Položky:</h3>
    `;
    
    // Přidáme položky
    cart.forEach(item => {
        let itemAmount = item.price * item.quantity;
        
        // Převod na cílovou měnu, pokud je to potřeba
        if (item.currency !== currency) {
            if (item.currency === 'CZK' && currency === 'EUR') {
                itemAmount = itemAmount / exchangeRate;
            } else if (item.currency === 'EUR' && currency === 'CZK') {
                itemAmount = itemAmount * exchangeRate;
            }
        }
        
        invoiceHTML += `
            <div class="invoice-item">
                <div>
                    <span class="cart-item-quantity">${item.quantity}x</span>
                    ${item.name}
                </div>
                <div>${itemAmount.toFixed(2)} ${currency}</div>
            </div>
        `;
    });
    
    // City tax
    invoiceHTML += `
        <div class="invoice-item" style="font-style: italic; margin-top: 10px;">
            <div>
                City Tax (${guests} ${guests > 1 ? 'osob' : 'osoba'} × ${nights} ${nights > 1 ? 'nocí' : 'noc'} × 2 EUR)
            </div>
            <div>${cityTax.toFixed(2)} ${currency}</div>
        </div>
    `;
    
    // Celkové shrnutí
    invoiceHTML += `
        <div class="subtotal">Mezisoučet za položky: ${itemsSubtotal.toFixed(2)} ${currency}</div>
    `;
    
    if (discount) {
        invoiceHTML += `
            <div class="discount">Sleva 10% (pouze na položky): -${itemsDiscount.toFixed(2)} ${currency}</div>
        `;
    }
    
    invoiceHTML += `
        <div class="subtotal">Položky po slevě: ${itemsTotal.toFixed(2)} ${currency}</div>
        <div class="subtotal">City Tax: ${cityTax.toFixed(2)} ${currency}</div>
    `;
    
    // Celková částka a způsob platby
    invoiceHTML += `
        <div class="total">Celkem: ${finalTotal.toFixed(2)} ${currency}</div>
        <div class="payment-method">Způsob platby: ${getPaymentMethodName(paymentMethod)}</div>
        <div class="invoice-actions">
            <button class="print-btn" onclick="printInvoice()">Tisk faktury</button>
            <button class="close-btn" onclick="closeInvoice()">Zavřít</button>
        </div>
    `;
    
    // Nastavíme obsah a zobrazíme fakturu
    invoiceContent.innerHTML = invoiceHTML;
    invoiceModal.style.display = "flex";
}

// Získání názvu způsobu platby
function getPaymentMethodName(method) {
    switch(method) {
        case 'cash': return 'Hotově';
        case 'card': return 'Kartou';
        case 'unpaid': return 'Neplaceno';
        default: return method;
    }
}

// Tisk faktury
function printInvoice() {
    window.print();
}

// Zavření faktury
function closeInvoice() {
    const invoiceModal = document.getElementById("invoiceModal");
    if (invoiceModal) {
        invoiceModal.style.display = "none";
    }
}

// Funkce pro dokončení objednávky
function checkout() {
    if (cart.length === 0) {
        alert("Košík je prázdný. Přidejte prosím položky do košíku.");
        return;
    }
    
    // Generujeme fakturu
    generateInvoice();
    
    // Po vytvoření objednávky bychom mohli resetovat košík
    if (confirm("Přejete si po vytvoření objednávky vyprázdnit košík?")) {
        cart = [];
        updateStats();
        toggleCart(); // Skryjeme košík
    }
}

// Aktualizace směnného kurzu
function updateExchangeRate() {
    const newRate = prompt("Zadejte nový kurz EUR/CZK:", exchangeRate);
    if (newRate === null) return;
    
    const parsedRate = parseFloat(newRate);
    if (isNaN(parsedRate) || parsedRate <= 0) {
        alert("Prosím zadejte platný kurz.");
        return;
    }
    
    exchangeRate = parsedRate;
    updateStats();
    alert(`Kurz aktualizován na 1 EUR = ${exchangeRate} CZK`);
}